// DNet.h
// another header of headers


#include "DTCP.h"

#include "DGopher.h"
#include "DGoList.h"
#include "DGoPlus.h"
#include "DGoClasses.h"
#include "DGoInit.h"
#include "DGoDoc.h"
#include "DGoNetDoc.h"
#include "DGoPrefs.h"

#include "DSMTPclient.h"
#include "DSendMailDialog.h"

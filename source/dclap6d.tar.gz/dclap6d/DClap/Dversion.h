/* Dversion.h */

#ifndef _DCLAP_VERSION_
#define _DCLAP_VERSION_

#ifdef __cplusplus
extern "C" {
#endif

extern const	short		kDCLAPVersion;
extern const	char*		kDCLAPVersionString;


#ifdef __cplusplus
}
#endif

#endif

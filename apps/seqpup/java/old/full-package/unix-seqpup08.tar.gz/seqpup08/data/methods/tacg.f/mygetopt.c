/* replacement for unixism getopt() in otherwise ansi c code */
/* dgg */

#include <ctype.h> 
#include <string.h> 
#include <stdlib.h>
/*#include <unistd.h>*/
#include <stdio.h>

#undef UseSystemGetopt

char* myOptarg;
int atarg = 0; /* how do we reset this? */

static char switchChar = '-';
static char optflagChar = ':';

/*
 while ((c = myGetopt(argc, argv, "chHlLqsSvVb:C:D:e:f:F:g:G:m:M:n:o:O:p:P:t:T:r:R:w:")) != EOF) {
*/

int myGetopt(int argc, char** argv, char* opts);
int myGetopt(int argc, char** argv, char* opts)
{
#ifdef UseSystemGetopt
	int val= getopt( argc, argv, opts);
	myOptarg= optarg;
	return val;
#else
	static int atargi= 1;
	int val= EOF;
	while (atarg < argc) {
		char* a= argv[atarg];
		if (atargi >= strlen(a)) { atargi= 1; a= argv[++atarg]; }
		if (a != NULL && *a == switchChar) {
			char* atopts;
			atopts= strchr(opts, a[atargi]);
			if (atopts != NULL) {
				val= a[atargi];
				if (atopts[1] == optflagChar) {
					atargi= 1;
					atarg++;
					if (a[2] > 0) myOptarg= a + 2;  
					else myOptarg= argv[atarg++]; 
					}
				else atargi++;
				return val;
				}
			}
		atarg++;
		}
	return val;
#endif
}



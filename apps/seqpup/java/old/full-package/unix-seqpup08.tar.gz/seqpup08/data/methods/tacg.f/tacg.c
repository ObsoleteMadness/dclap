/* Program tacg V2.29 - a command line tool for Restriction Enzyme digests of DNA  */
/* Copyright � 1996,1997 Harry J Mangalam, University of California, Irvine 
   (mangalam@uci.edu, 714 824 4824) */

/* The use of this software (except that by Harald T. Alvestrand, which is described in 'udping.c')
   is bound by the notice that appears in the file 'tacg.h' which should accompany this file.  In the event 
   that 'tacg.h' is not bundled with this file, please contact the author.
*/
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h> 
#include "tacg.h"   /* contains all the defines, includes, function prototypes for both main() and functions; 
                      simple enuf not to have a version #; I'll just keep it up to date as I go...*/

struct RE_struct *RE;
struct ORF_struct *ORFs[6];
struct Digest_Data *DD; 
struct Prox_struct PP[10];


/* Below is the declaration for flags[] - longer description is in SetFlags.c */
long flags[NFLAGS] = 
/* 0 1 2 3     4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40
   f n o m     M b e g l t  T  O  v  h  i  c  r  R  C  F  L  S  w  H  c  V  s  d  D  p  P |- fr 2B ORFed -|  E  G  G io */
  {1,3,1,1,32000,1,0,0,0,1, 0,-1,-1,-1, 1, 1,-2,-2, 0,-1, 0, 0,60, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}; 


/* dgg - moved these out of main proc so it wouldn't eat of limited stack-based memory */


static char  O_txt[MAX_OUTPUT_LINES][O_LMARG+O_RMARG+MAX_BASES_PER_LINE];
/* These next 2 assignments cut out a function call and a number of file ops (saves all of .2 s), but makes the dist and 
        setup easier by a file.  Since I doubt anyone will mess with the codon usage tables, may as well make them static. */
static char * Codons[MAX_ORGS][N_CODONS] = {
        {"KLys","QGln","EGlu","*OCH","TThr","PPro","AAla","SSer","RArg","RArg","GGly","*OPA","IIle","LLeu","VVal","LLeu",
         "NAsn","HHis","DAsp","YTyr","TThr","PPro","AAla","SSer","SSer","RArg","GGly","CCys","IIle","LLeu","VVal","FPhe", 
         "KLys","QGln","EGlu","*AMB","TThr","PPro","AAla","SSer","RArg","RArg","GGly","WTrp","MMet","LLeu","VVal","LLeu", 
         "NAsn","HHis","DAsp","YTyr","TThr","PPro","AAla","SSer","SSer","RArg","GGly","CCys","IIle","LLeu","VVal","FPhe"},
        {"KLys","QGln","EGlu","*OCH","TThr","PPro","AAla","SSer","*STP","RArg","GGly","WTrp","MMet","LLeu","VVal","LLeu",
        "NAsn","HHis","DAsp","YTyr","TThr","PPro","AAla","SSer","SSer","RArg","GGly","CCys","IIle","LLeu","VVal","FPhe",
        "KLys","QGln","EGlu","*AMB","TThr","PPro","AAla","SSer","*STP","RArg","GGly","WTrp","MMet","LLeu","VVal","LLeu",
        "NAsn","HHis","DAsp","YTyr","TThr","PPro","AAla","SSer","SSer","RArg","GGly","CCys","IIle","LLeu","VVal","FPhe"},
       {"KLys","QGln","EGlu","*OCH","TThr","PPro","AAla","SSer","SSer","RArg","GGly","WTrp","MMet","LLeu","VVal","LLeu",
        "NAsn","HHis","DAsp","YTyr","TThr","PPro","AAla","SSer","SSer","RArg","GGly","CCys","IIle","LLeu","VVal","FPhe",
        "KLys","QGln","EGlu","*AMB","TThr","PPro","AAla","SSer","SSer","RArg","GGly","WTrp","MMet","LLeu","VVal","LLeu",
        "NAsn","HHis","DAsp","YTyr","TThr","PPro","AAla","SSer","SSer","RArg","GGly","CCys","IIle","LLeu","VVal","FPhe"},
       {"KLys","QGln","EGlu","*OCH","TThr","PPro","AAla","SSer","RArg","RArg","GGly","WTrp","MMet","TThr","VVal","LLeu",
        "NAsn","HHis","DAsp","YTyr","TThr","PPro","AAla","SSer","SSer","RArg","GGly","CCys","IIle","TThr","VVal","FPhe",
        "KLys","QGln","EGlu","*AMB","TThr","PPro","AAla","SSer","RArg","RArg","GGly","WTrp","MMet","TThr","VVal","LLeu",
        "NAsn","HHis","DAsp","YTyr","TThr","PPro","AAla","SSer","SSer","RArg","GGly","CCys","IIle","TThr","VVal","FPhe"},
       {"KLys","QGln","EGlu","*OCH","TThr","PPro","AAla","SSer","RArg","RArg","GGly","WTrp","IIle","LLeu","VVal","LLeu",
        "NAsn","HHis","DAsp","YTyr","TThr","PPro","AAla","SSer","SSer","RArg","GGly","CCys","IIle","LLeu","VVal","FPhe",
        "KLys","QGln","EGlu","*AMB","TThr","PPro","AAla","SSer","RArg","RArg","GGly","WTrp","MMet","LLeu","VVal","LLeu",
        "NAsn","HHis","DAsp","YTyr","TThr","PPro","AAla","SSer","SSer","RArg","GGly","CCys","IIle","LLeu","VVal","FPhe"},
       {"KLys","QGln","EGlu","*OCH","TThr","PPro","AAla","SSer","RArg","RArg","GGly","WTrp","IIle","LLeu","VVal","LLeu",
        "NAsn","HHis","DAsp","YTyr","TThr","PPro","AAla","SSer","SSer","RArg","GGly","CCys","IIle","LLeu","VVal","FPhe",
        "KLys","QGln","EGlu","*AMB","TThr","PPro","AAla","SSer","RArg","RArg","GGly","WTrp","MMet","LLeu","VVal","LLeu",
        "NAsn","HHis","DAsp","YTyr","TThr","PPro","AAla","SSer","SSer","RArg","GGly","CCys","IIle","LLeu","VVal","FPhe"},
       {"KLys","QGln","EGlu","*OCH","TThr","PPro","AAla","SSer","RArg","RArg","GGly","*OPA","IIle","LLeu","VVal","LLeu",
        "NAsn","HHis","DAsp","YTyr","TThr","PPro","AAla","SSer","SSer","RArg","GGly","CCys","IIle","LLeu","VVal","FPhe",
        "KLys","QGln","EGlu","*AMB","TThr","PPro","AAla","SSer","RArg","WTrp","GGly","WTrp","MMet","LLeu","VVal","LLeu",
        "NAsn","HHis","DAsp","YTyr","TThr","PPro","AAla","SSer","SSer","RArg","GGly","CCys","IIle","LLeu","VVal","FPhe"},
       {"KLys","QGln","EGlu","QGln","TThr","PPro","AAla","SSer","RArg","RArg","GGly","*OPA","IIle","LLeu","VVal","LLeu",
        "NAsn","HHis","DAsp","YTyr","TThr","PPro","AAla","SSer","SSer","RArg","GGly","CCys","IIle","LLeu","VVal","FPhe",
        "KLys","QGln","EGlu","QGln","TThr","PPro","AAla","SSer","RArg","RArg","GGly","WTrp","MMet","LLeu","VVal","LLeu",
        "NAsn","HHis","DAsp","YTyr","TThr","PPro","AAla","SSer","SSer","RArg","GGly","CCys","IIle","LLeu","VVal","FPhe"}};





#ifdef MACINTOSH

int RealMain(int argc, char *argv[]) 

#else

int main(int argc, char *argv[]) 

#endif
{  

/* Key variable descriptions
i,j, k,l,m,mm,li  : general counters; 
li,lj       long counters to allow large counts
key         array that holds the keys for generating the hash values of the DNA hexamers
el          counter for 'key[]', above
sum         array for keeping score of the degenerate sums
degen       degeneracy
NumRES      the calculated # of REs (as opposed to MAX_NUM_RES, the maximum #). 
            As of V 2, RE starts at 0 like any other array.  The offset-of-10 problem has been addressed.
baseK       constant for determining the values for the dif bases
t_degen     top of the degen array (usually degen-1)
RE_rawsite  temp char array
s           temp pointer to char
nucleotide  the current nucleotide for switch statement
hashtable   2D array that has both the original index [0] that counts how many Enz primary hexamers map to a 
            particular el ie - how many Enz either do or could cut at that location.  The other D holds the 
            data that was in earlier versions, stored in chk_sits - an array of size [0]+1 that holds the reverse
            mappings for each of the hash values - which RE entries map to that hash value for extended checking in
            the Cutting section.
*chk_sits[] archaic - now incl in hashtable - see above.   
*Dig_Sits[] archaic - now incl in the RE struct as RE[].Sites[] 
*Frag_Siz[] archaic - now incl in the RE struct as RE[].Frags[] - the array that keeps track of the fragments 
            generated by the cutting (sister of *Dig_Sits[], 0th element is used  as a pointer to the end.

*Dig_Dat    archaic - now incl the struct DD->Dat[].  The array (init'ed to 10,000 (enough for a sequence of about 
            50,000) and calloc'ed larger if needed) that keeps the data as it is generated for later 
            sorting and use in *Dig_sits[] (see above).  It's format is:
            base cut site|RE#|base cut site|RE#|base cut site|RE#|base cut site|RE#| 
D_D_Cnt     archaic - now incl the struct DD->*Cnt. counter for dig_dat[]
D_D_Siz     archaic - now incl the struct DD->*Siz. Size of Dig_Dat[], used to realloc more mem for DD->Dat.

*Codons[][] the array that holds the codon preference data - list of labels indexed by hash of the corresponding
            codon triplet.
*Codon_Labels[]  Array that holds the organism labels of the different codon preference tables     
Cur_RE      'Current RE Number' - simplifying var for a longer, more confusing array reference in printing bit
Base_cutsite   the base site at which the RE cuts (not considering the offset (RE[].E_tcut) which will 
            vary for each enzyme
O_txt[][]   char array to hold each 'block' (one line of sequence w/ associated REs, #s, translations, etc) 
            as it's being prepped for output
ok2wr[]     int array to hold the position markers that indicate where in O_txt it's 'OK to write' an RE name
            so that it doesn't overwrite a previous one
okline      index to ok2wr that starts at (O_SEQ_LINE-2) and decrements to keep track of where the next 
            line and position is that's ok to write to.  
block_Cnt   keeps track of how many blocks have been output to calculate where we are in the sequenc
base_real_pos  real world coordinates of where we are in the sequence
block_repeat   do the 'compose block, print block' routine this many times
block_cut_pos  base_real_pos modified by the offset of where the RE actually cuts
SHKey       Sequence Hash Key, the hash key generated from the previous sequence hexamer by the 
            'shortcut' method, mentioned below
lead        the leading value in the shortcut method 'lead a g t g t'
lag         the lagging value in the shortcut method  'a g t g t lag'
eoseq       pointer to the end of the alloc for the sequence
*GREs       ARCHAIC - now use RE directly -pointer to array for the indices to the 'Good REs' vs the doppelgangers (2nd half of the nonpals
NumGREs     ARCHAIC - now use NumREs references directly -the number of Good REs (size of GREs above)
Gi          ARCHAIC - now use 'i' alone - refers directly to the RE index 
topo        topology - 0 if the DNA is circular, 1 if linear - makes sense, no?
BOS         Beginning Of Sequence - marker for BOS changes depending on topo
EOS         End Of Sequence - "
VERBOSE     if set to 1, print error messages to std err; otherwise shaddup!
*   The identifier string for the program that gets passed to the udp function sayiamhere()  
*EnzFileName    holds the name of the alternative REBASE file name, if specified on the command line
*/ 

/* Declarations */
/* struct Digest_Data *DD; */
   int i, j, k, b, e, mm, m, n_letters=0, thisframe=0, moo=0, *hashtable[4096], NumREs, okline, codon_Table=0, 
   		NumProtos=0, min_okline, tic_line, Cur_RE, block_Cnt, block_repeat, gel=0, HTML, max_okline, block_cut_pos, 
   		ok2wr[MAX_OUTPUT_LINES], ProtoCutters, *Protos, **Grfdata, Nbins, W, p_width, topo, abcp,  basesPerLine, 
   		reps, in_OL=-1, seq_offset, VERBOSE;

   long  *BackCheck, /* BackCheck[] checks proto entries in the Linear map output to remove duplicates */
         DCnt, l, Cnt_reset=0, Base_cutsite,  seq_len, tot_seq_Cnt = 1, Xn, base_real_pos; 

   char *sequence, *TmpSeq, *Prot4ORF, ctemp1[30], s[256], 
        Prot_out[MAX_BASES_PER_LINE], progname[200], *EnzFileName, SelEnz[MAX_SEL_ENZ][11];
   
/* Leave this array in for people who want to restore the Codons from file */
/*   char *Codon_Labels[MAX_ORGS] = {"Universal","Mito_Vertebrates","Mito_Drosophila","Mito_S_Cervisiae",
                                   "Mito_S_Pombe","Mito_N_crassa","Mito_Higher_Plants","Ciliates"}; 
*/   
extern struct ORF_struct *ORFs[6];
extern struct Prox_struct PP[10];
   
   FILE *tmpfp;
   tmpfp = tmpfile();
   if (tmpfp == NULL) { fprintf(stderr,"!!tempfile creation failed - que??\n"); exit (1); }
   fprintf(tmpfp, "Temporary file created by tacg.\n..\n");

/* Initialize whatever vars are needed */
   NumREs=1;  /* now starts NOT at 0 like a good little array, but at 1, cuz I use negation to mark doppels */
   
/* Let's try it again - RE as a realloc-able pointer */
   RE = calloc(INIT_RES, sizeof(*RE)); 
   if (RE == NULL) BadMem("Can't init mem for RE", 1);
   
/* since DD is pointer to struct, have to explicitly get mem for it */
   DD = calloc(1, sizeof(*DD)); 
   if (DD==NULL) BadMem("Can't init mem for DD", 1);   
   DD->Dat = (long *) calloc(10000, sizeof(long)); /* init the pointer to 10,000 */
   if (DD->Dat== NULL) BadMem("calloc failed -> DD->Dat mem!", 1);
   DD->Dat[0] = 2;      /* this is Cnt and it has to start at 2 to skip these two unholy counters */
   DD->Dat[1] = 10000;  /* this is Siz */
   
   memset(SelEnz,' ',(MAX_SEL_ENZ*11));
   	
/* Figure out what the program should do, by parsing the commandline options */   
/* if the program is invoked by name alone, tell the user how to use it */
   if (argc < 2 ) {
   	fprintf(stderr, "type 'tacg -h' for more help on program use. \n"); 
		exit(1);
   }
/* Now get and process the flags and return the alt REBASE file, if any */
   EnzFileName = SetFlags(argc, argv, SelEnz, tmpfp);
   if (flags[40] == 0) { /* then no output flags have been set, ergo no output will be generated */
		fprintf(stderr, "You haven't requested any output.  You need to explicitly ask for it.\n"
							 "Use any of: -F -g -G -l -L -O -P -s -S. Type 'tacg -h' for a brief usage.\n");
		exit(1);
   }
   if (flags[17] != 1)  EnzFileName = SearchPaths("rebase.data", "REBASE");

/*  'Read_Codon_Prefs' line below not needed with static decl above, but if you want to put them back in... */
   /* Open and process the "codon.prefs" file via function Read_Codon_Prefs ()  */
   /* Read_Codon_Prefs (Codons, Codon_Labels); */

/* Get the sequence from stdin, format it into 'sequence', bracket it with overlaps to allow circular
   cutting and return it's actual length.  Format below is required because sequence is realloc'ed 
   in the function */
   sequence = GetSequence( &tot_seq_Cnt, &seq_len);
   
/* set up more vars, based on flags - could use only array to pass vars, but this is more readable */
   topo = (int)flags[0]; 
   basesPerLine = (int)flags[22];
   p_width = O_LMARG + O_RMARG + basesPerLine;
   memset(O_txt,' ',((O_LMARG+O_RMARG+MAX_BASES_PER_LINE)*MAX_OUTPUT_LINES));  /* set all of O_txt to blanks - works!*/
   if (flags[7] != 0) gel = 1;
   HTML = (int)flags[23];
   VERBOSE = (int)flags[25];
   
/* Decide from flags how to handle translation options ... */
   if (flags[9] != 0)  {Xn = flags[9]; n_letters = 1; } 
   else {Xn = flags[10]; n_letters = 3; }

   max_okline =  O_SEQ_LINE + 4 + (int)labs(Xn); /* how many more lines of output are required for the translation */
   codon_Table = (int)flags[18]; /* which Codon Table to use in Translate() */

   
/* Get and process the Enzymes from the rebase or alternate file */
/*   hashtable = ReadEnz(EnzFileName, &NumREs, SelEnz, hashtable); */
   NumProtos = ReadEnz(EnzFileName, tmpfp, &NumREs, SelEnz, hashtable); 
   if (flags[25] ==1) fprintf(stderr, "\n# of Prototype patterns = %d; Total # RE Entries = %d\n", NumProtos, NumREs);
   
/* Now calloc the Protos[] array using the NumProtos; used to crosscheck Sites output and to sort/re-sort RE entries */
   Protos = (int *)calloc(NumProtos, sizeof(long));
   if (Protos == NULL) BadMem("Can't init mem for Protos", 1);

   BackCheck = (long *)calloc(NumREs, sizeof(long));
   if (BackCheck == NULL) BadMem("Can't init mem for BackCheck", 1);

   if (topo == 0)  {          /* if the sequence is circular */
      DD->BOS = 1;                /* Beginning Of Sequence starts at the very beginning of 'sequence' */
      DD->EOS = tot_seq_Cnt;      /* and End Of Sequence ends at very end  */
   } else {                   /* but if it's linear */
      DD->BOS = BASE_OVERLAP + 1; /* BOS starts after the beginning buffer */
      DD->EOS = tot_seq_Cnt - BASE_OVERLAP;   /* and EOS is before the ending buffer */
   }
   
/************   Here's where the rubber hits road.. Go and cut/match the sequence   *****************/
/* as tacg expands it repertoire, there are now a few functions that do not require the restriction analysis,
	so there should be a test to skip it if it's not necessary - not implemented yet tho...*/
	
/*	if (argc > 2 || flags[11] == -1) { */
	
		Cutting(sequence, hashtable); /* this is all there is left in main() */
	
	/* translate the data from DD->Dat to Dig_Sits for calc'ing fragment sizes */
	   /* calloc the space for *RE[].Sites and sister array *Frag_Siz[] and init the 0th el to point to 1st free spot */
	   for (i=1;i<NumREs;i++) { /* start at 1, NOT 0, fool! */
	      RE[i].Sites=(long *) calloc (RE[i].E_Ncuts+2, sizeof(long));
	      if (RE[i].Sites==NULL) BadMem("!! calloc failed: RE[i].Sites\n", 1);
	      RE[i].Sites[0] = 1;      /* the [i][0] el points to the next free element, so init here */
	      
	      RE[i].Frags=(long *) calloc (RE[i].E_Ncuts+2, sizeof(long)); /* need '+2' for extra frag */
	      if (RE[i].Frags==NULL) BadMem("!!calloc failed: RE[i].Frags\n", 1);
	   }   
	   
	/* The following loads Dig_Sits[], the array that tracks the digestion sites  */
	
	   i=2; /* REMEMBER - DD->Dat real data starts at [2]; [0] is Cnt, [1] is Siz */
	   while (DD->Dat[i] != -2) { /* -2 is the end point indicator */
	      Base_cutsite = DD->Dat[i++]; /* i now points to RE# */
	      mm = (int)labs(DD->Dat[i++]); /* shortens next line, incr's i to point to next position */ 
	      if ( RE[mm].Sites[RE[mm].Sites[0]-1] != Base_cutsite ) { /* if it's not the same as the one before (-P, degens) */
	         RE[mm].Sites[RE[mm].Sites[0]++] = Base_cutsite;   /* weird, self-referential definition, but.. it works.. */
	      }
	      RE[mm].E_Ncuts = RE[mm].Sites[0]-1; /* adjustment for the above adjustment */
	   }    /*   [RE#] [Pointer to next free el++ ]     */     
		
	/* Dig_Sits now loaded with REAL WORLD Coords so calc'n of Frag_Siz should be accurate */
	   
	/* This next stanza takes care of removing the last jitter from the RE[].Sites.  If there is substantial 
	   overlapping cutting, such as '-pname,wwwwwwwwwwwwwwww,1' (thanks Wes), there will be a very large amount of
	   jitter that remains even after the check in Cutting() that checks to see if the previous cut point is the 
	   same as the next (ie .. 213 214 213 215 213 216 214 213 ...) so this next stanza definitively trues the 
	   array, leaving a max of one name per base.   */
	   
	   for (i=1;i<NumREs; i++) { /* start at 1, NOT 0, fool! */
	      /* if it's a proto && there are non-protos immediately following || a gonzo degeneracy (-D > 2)  */
	      if ((flags[14] > 2 || (i == RE[i].proto && RE[i+1].proto == i)) && RE[i].E_Ncuts > 0) { 
	         qsort(RE[i].Sites+1, RE[i].E_Ncuts, sizeof(long), compare); /* sort the cutsites to remove the jitter */
	         for (j=2,k=1; j<=RE[i].E_Ncuts; j++) { /* #s actually start @ '1'; pack the unique values in the same space */
	            if (RE[i].Sites[j] != RE[i].Sites[k]) {
	               RE[i].Sites[++k] = RE[i].Sites[j];
	            }           
	         }
	         RE[i].E_Ncuts = k; /*  +1;  reset the Ncuts counter needs the '+1' to bump it up to the end ..??? */
	      }
	   }
	   
	/* Now calc fragment sizes, sort in increasing size, now using REAL WORLD Coords so frags should be 
	   exactly right size - also have to consider topology for 1st and last cut*/
	   for (i=1;i<NumREs;i++) {  /* the lower index point starts @ '1' */
	      if (RE[i].E_Ncuts != 0) { /* using 'l' as index -> Ncuts+1 frags in linear, counting the 0th el*/
	         l = RE[i].E_Ncuts;  /* need a modifiable variable;  */
	         if (topo == 1) {  /* handling topo diffs - if it's linear... */
	            RE[i].Frags[0] = RE[i].Sites[1];/* 1st frag will be magnitude of 1st cut */
	            RE[i].Frags[l] = seq_len - RE[i].Sites[l];/* last frag will be length of sequence - last cut */
	         } else { /* otherwise it's circular and the 1st frag is the size of the above 2 combined ...*/
	            RE[i].Frags[0] = RE[i].Sites[1] + seq_len - RE[i].Sites[l];
	            RE[i].Frags[l] = 0; /* and the 'last' doesn't exist (size 0) */
	         }
	         if (RE[i].E_Ncuts > 1) {
	            for (j=1;j<RE[i].E_Ncuts;j++)   {
	               RE[i].Frags[j] = labs(RE[i].Sites[l] - RE[i].Sites[l-1]); /* frag = site nearer end - next site  */
	               l--;  /* need the 'labs' because using REAL WORLD coords, it's possible to get negative values by */
	            }        /* same offset cutting RE site on diff strands in close proximity */
	         }
	      } else RE[i].Sites[0] = seq_len;  /* if it doesn't cut, the fragment is the size of sequence */
	   }
/*	} */

/******************************************************************************************************
*      									Now, starting the OUPUT phase   													*
*******************************************************************************************************/
   /* Load Protos with the names of those REs that have > 0 cuts  */
   j=0;
   for (i=1; i<NumREs; i++) { /* start at 1, stupid */
      if (RE[i].proto == i && RE[i].E_Ncuts >0) Protos[j++] = i; /* if it's a proto && has more than 0 cuts */
   } 
   ProtoCutters = j;

/* Output a Summary table of REs that do not cut, if -S flag is set */
   if (flags[26] == 1) {  /* only output the summary if really wanted */
      fprintf(stdout, "\n\n");
      if (HTML==1) fprintf(stdout, "<H3><A NAME=\"nocuts\">");
      fprintf (stdout," == Enzymes that DO NOT MAP to this sequence:\n");
      if (HTML==1) fprintf(stdout, "</A></H3>\n"); 

      reps = (int)((O_LMARG+O_RMARG+basesPerLine)/10 - 1);
      i=0; j=0; Cur_RE = 1;
      while (Cur_RE < NumREs && RE[Cur_RE].proto == Cur_RE) {
         if (RE[Cur_RE].E_Ncuts == 0) { fprintf(stdout, "%11s", RE[Cur_RE].E_nam); j++; i++;}
         if (j == reps) { printf ("\n"); j=0; }
         Cur_RE++;
      }
      if (i==0) fprintf(stdout, "\n\tThere were NO NON-matches - ALL patterns matched at least ONCE.\n");
   
   /* Now, just output a table of the number of cuts by enzyme if they have 1 or more cuts */
      fprintf(stdout, "\n\n\n");
      if (HTML==1) fprintf(stdout, "<H3><A NAME=\"allcuts\">");   
      fprintf (stdout, " == Total Number of Hits per Enzyme:\n\n");
      if (HTML==1) fprintf(stdout, "</A></H3>\n"); 
      
      reps = (int) (((O_LMARG+O_RMARG+basesPerLine)/15)-1);
      m = (int) (ProtoCutters/reps)+1; 
      for (i=0;i<m;i++) {
         for (j=0;j<reps && i+(j*m)<ProtoCutters;j++) {
            fprintf(stdout, "%11s%6d", RE[Protos[i+(j*m)]].E_nam, RE[Protos[i+(j*m)]].E_Ncuts);
         }
         fprintf(stdout,"\n");
      }
   }

   reps = (int) ((O_LMARG+O_RMARG+basesPerLine)/7); /* needed for both PrintSites() and PrintFrags() */
	/* Use Protos instead of GREs - should be close to a 1:1 correspondence */
   /* Use this gruntsort routine to sort GREs in place according to # cuts for each enzyme-
   don't have to change a thing then for the site/fragment/ladder/gel output!!  Otherwise, 
   it's just dumped by order of their listing in REBASE */ 
   if (flags[24]==1) { /* if want the frag, sites, etc listed by number of cuts (-c flag)*/
      for (j=0;j<ProtoCutters;j++) {
         for (k=j+1; k<ProtoCutters; k++) {
            if (RE[Protos[j]].E_Ncuts > RE[Protos[k]].E_Ncuts) {
               mm = Protos[j]; Protos[j] = Protos[k]; Protos[k] = mm;
            }
         }
      }      
      /* and now resort on basis of RE names so that it will be alphabetic within cut bins */
      j=k=b=e=0;

      while (e < ProtoCutters) {
         while (RE[Protos[e]].E_Ncuts == RE[Protos[j]].E_Ncuts) e++;
         for (j=b; j<e; j++) {
            for (k=j+1; k<e; k++) {
               if (strcmp(RE[Protos[j]].E_nam , RE[Protos[k]].E_nam) > 0) {
                  mm = Protos[j]; Protos[j] = Protos[k]; Protos[k] = mm;
               }
            }
         }
         b=e;
      }
   }

/* And if wanted (-S), print out all the cut sites, filtered as below in PrintFrags() */
   if (flags[21] == 1) PrintSitesFrags(ProtoCutters, reps, Protos, 1);
   
/* if asked for -P matching, do the name site matching calculations */   
   if (flags[30] > 0) {
   	Proximity();  
   	/* 	PrintGelLadderMap(int NumProtos, long seq_len, int *Protos, int gel);  */
		PrintGelLadderMap(flags[30], seq_len, Protos, 4);		
   }

/* Now if wanted, print out the UNsorted fragments generated by the cuts, listed across the page. 
   This routine also uses a very large number of printf calls to generate the output format and 
   might be better written to 'compose and dump' entire lines rather than doing it piecewise 
   as it does here - advice is welcome. */

   mm = (int)flags[19];
   if (mm==1 || mm==3) { /* if want *unsorted* or *both sorted and unsorted * frags */
      printf("\n\n\n"); /* prefix to PrintFrag() title */
      if (HTML==1) fprintf(stdout, "<H3><A NAME=\"fragunsort\">"); /* HTML tags for the TOC */
      printf("  **  UNSORTED "); /* prefix to PrintFrag() title */
      PrintSitesFrags(ProtoCutters, reps, Protos, 0); /* subst 'ProtoCutters' for 'NumGREs', 'Protos' for 'GREs' */
   }    

   if (mm==2 || mm==3 || (gel==1)) { /* if want *sorted* or if need sorted for gel */
      for (i=1;i<NumREs;i++) {  /* the lower index point starts @ '1', not '10' because we're using GREs[] */
         if (topo == 0) j = RE[i].E_Ncuts; /* j is used to pass the number of els to qsort */
         else j = RE[i].E_Ncuts+1; /* if topo == 1, then there's an extra fragment */
         qsort(RE[i].Frags, j, sizeof(long), compare); /* 2X as fast as braindead sort!) */
      } /* Now they're sorted! Just use PrintFrags again to dump them out */

      if (gel) {
        PrintGelLadderMap(ProtoCutters, seq_len, Protos, gel); /* subst 'ProtoCutters' for 'NumGREs', 'Protos' for 'GREs' */
      }

      if (mm==2 || mm==3){
        printf("\n\n\n"); /* prefix to PrintFrag() title */
        if (HTML==1) fprintf(stdout, "<H3><A NAME=\"fragsort\">");
        printf("  **  SORTED "); /* prefix to PrintFrag() title */
        PrintSitesFrags(ProtoCutters, reps, Protos, 0); /* subst 'ProtoCutters' for 'NumGREs', 'Protos' for 'GREs' */
      }
   }

   if (flags[8] == 1) {  /* if want a text-ladder map of the sequence */
      PrintGelLadderMap(ProtoCutters, seq_len, Protos, 0);  /* subst 'ProtoCutters' for 'NumGREs', 'Protos' for 'GREs' */
   }
   
   if (flags[38] > 0) {  /* if want the RE data streamed out as data appropriate for graphing */
   	W = flags[39];  /* flags[39] indicates the type of output wanted - 1 = 'square' output (Bins X, REs Y) */
   	/*	2 = 'square' output (Bins Y, REs X), 3 = long output (2 cols, reiterated Bins (X), RE data(Y) */
   	Nbins = (int) (seq_len/flags[38]) + 1; /* Nbins = # bins required */
   	Grfdata = (int **) calloc(Nbins, sizeof(int*)); /* init the rows of pointers for Grfdata */
   	if (Grfdata == NULL) BadMem("Can't init mem for Grfdata", 1);
   	for (i=0; i<Nbins; i++) { /* and all the columns */
   		Grfdata[i] = (int *) calloc(ProtoCutters+1, sizeof(int));
   		if (Grfdata[i] == NULL) BadMem("Can't init mem for Grfdata[i]", 1);
   	}
   	
		fprintf(stdout, "\n\n\n"); /* prefix to GraphData title */
     	if (HTML==1) fprintf(stdout, "<H3><A NAME=\"graphdata\">");
    	fprintf(stdout, " == Graphics Data\n\n"); /* Print the header title */
    	
    	l = flags[38];
    	for (i=0; i<Nbins; i++) { /* loads the Bins #s for Grfdata */
    		Grfdata[i][0] = l;
    		l += flags[38];
    	}
 		/* now load the RE data part */
   	for (i=0;i<ProtoCutters; i++) { /* for each of those REs that have more than 1 hit */
   		for (j=1; j<RE[Protos[i]].Sites[0]; j++) { /* for each hit */
   			Grfdata[(int)(RE[Protos[i]].Sites[j]/flags[38])][i+1]++; /* base hit / (#bases/bin) */
   		}
		} /* on exit, data is loaded correctly */
		/* now the diff output forms, massaging the square array Grfdata into the right shape */
		if (W == 1) { /* square, Bins X, REs Y, (original format) */
			/* 1st print the Bins out */
			fprintf(stdout, "      Bins");
			for (i=0;i<Nbins;i++)  fprintf(stdout, "%8d ", Grfdata[i][0]);
			fprintf(stdout, "\n");
			for (i=1; i<ProtoCutters+1; i++) {
				fprintf(stdout, "%10s", RE[Protos[i-1]].E_nam); /*print RE label */
				for (j=0; j<Nbins; j++) fprintf(stdout, "%8d ", Grfdata[j][i]); /* and the # */
				fprintf(stdout, "\n");
			}
		} else if (W == 2) { /* square, Bins Y, REs X, (diagonal flip of original format) */
			fprintf(stdout, "#     Bins"); /* 1st print out the header line with 'Bins' */
			for (i=0; i<ProtoCutters; i++) { /* and the RE labels */
				fprintf(stdout, "%10s", RE[Protos[i]].E_nam); /*print RE label */
			}
			fprintf(stdout, "\n");
			
			for (i=0;i<Nbins; i++) {
				for (j=0; j<ProtoCutters+1; j++) fprintf(stdout, "%10d", Grfdata[i][j]); /* and the # */
				fprintf(stdout, "\n");
			}
		} else { /* Long, skinny form, reiterated Bins(X) RE(Y) for each RE */
			for (i=1; i<ProtoCutters+1; i++) {
				fprintf(stdout, "\n#     Bins  %10s\n", RE[Protos[i-1]].E_nam);
				for (j=0; j<Nbins; j++) {
					fprintf(stdout, "%10d %10d\n", Grfdata[j][0], Grfdata[j][i]);
				}
			}
		}
   	fprintf(stdout,"\n");
   }
   
   if (flags[11] != -1) { /* if want a table of ORF data */
      fprintf(stdout, "\n\n\n");
      if (HTML==1) fprintf(stdout, "<H3><A NAME=\"orfs\">");   
      fprintf (stdout, " == Open Reading Frame Analysis:\n");
      if (HTML==1) fprintf(stdout, "</A></H3>\n"); 

      for (i=31; i<37 && flags[i] != 0; i++){  /* jjj - did have a ',' instead of the '&&' */
         if (flags[i] >3 && flags[i] <7) {  
            /* have to get mem for and antipar sequence into a temp holder to submit to Translate, etc */
            l = strlen(sequence+1);
            TmpSeq = calloc(tot_seq_Cnt, sizeof(char));
            if (TmpSeq == NULL) BadMem("tacg.c:~464 TmpSeq calloc err", 1); 
            Anti_Par (sequence, TmpSeq, tot_seq_Cnt); /* now TmpSeq is pointing at the AP'ed sequence */
            /* also have to do some muddling with frame because have to convert frames 456 to 123 and 
               pass them correctly */
            moo = flags[i] - 3; /* minus ORF offset 4=1, 5=2, 6=3 */
         } else {
            TmpSeq = sequence;  /* else point TmpSeq at sequence as a temp pointer */
            moo = flags[i];
         }
            thisframe = flags[i];
            
            Prot4ORF = (char *)calloc((seq_len/3 + 2), sizeof(char));
            if (Prot4ORF == NULL) BadMem("tacg.c:~476 Prot4ORF calloc err", 1);
            Translate(TmpSeq+BASE_OVERLAP+moo, Prot4ORF, seq_len-moo, 2, Codons, codon_Table);
            ORF_Analysis(Prot4ORF, strlen(Prot4ORF), thisframe);
            free(Prot4ORF); 
            if (flags[i] >33 && flags[i] <37) free(TmpSeq);  /* else it points at sequence and bad mojo will happen */
      }
   }

/* if you want a linear map of the sequence */
   if (flags[20] == 1) {  

      /* Routine to print out the text of the digestion, with names going where they should go
      a la Strider - have to keep track of how long the names are and where an allowable place 
      to write the name - */

      /* In brief, the following procedure (which should probably be turned into a function), does this: 
      It reads thru DD->Dat (the array that keeps track of the linear sequence of cuts in the sequence) 
      and matches the position of the enzymes to the current block being printed, taking into account 
      the cut offset of the RE from the 1st base of the recognition sequence.  The tricky part is that 
      because of this latter functionality, it has to check the sequence that will be the *following* 
      block to see if there are any RE recognition seqs within the 1st few bases that will cause the actual 
      cut site to be in the *previous* block.  Doing this seems to take a great amount of the cpu time - can 
      probably be optimized a good deal more, but it's still >10 faster than GCG ;). */

      fprintf(stdout, "\n\n\n");
      if (HTML==1) fprintf(stdout, "<H3><A NAME=\"linmap\">");
      fprintf(stdout, " == Linear Map of Sequence:\n"); /* Write the header */ 
      if (HTML==1) fprintf(stdout, "</A></H3>\n");

      /* inits, etc */ 
      if (seq_len % basesPerLine == 0)  block_repeat = (int) seq_len/basesPerLine; /*  # times thru the compose/print cycle */
      else  block_repeat = (int) seq_len/basesPerLine + 1;  
      DCnt=2;  /* start the DD->Dat counter at the beginning of REAL DATA [0]=Cnt; [1]=Siz */
      base_real_pos = DD->Dat[DCnt];

      for (block_Cnt=1; block_Cnt <= block_repeat; block_Cnt++) { 
         /* if there was an OVERLAP failure previously, fix it */ 
         if (in_OL == 1) DCnt = Cnt_reset;  /* and reset DCnt to that pointer */ 
         in_OL = -1;  /* and reset 'in OVERLAP' marker for new block */
         base_real_pos = DD->Dat[DCnt];  /* Make sure that ' base_real_pos' is set */
         okline = min_okline = O_SEQ_LINE-2; /* set the min (highest on page) line of buffer to print out */

         /* Set up the seq and its rev compl in the ouput buffer */
         memset(ok2wr,0,sizeof(int)*MAX_OUTPUT_LINES);  /* set/reset all of ok2wr to 0's for the new block*/
         memset(BackCheck, 0, sizeof(long)*NumREs); /* reset the BackCheck[] */
         
         /*write the correct numbering in Left margin  */
         sprintf(s, "%7d",(((block_Cnt-1)*basesPerLine) + 1)); /* these 2 lines could be combined...? */
         memcpy(&O_txt[O_SEQ_LINE][0], &s, 7);
         /* and in the right margin - combine with the above bit? */
         sprintf(s, "%7d",(((block_Cnt)*basesPerLine)));
         memcpy(&O_txt[O_SEQ_LINE][O_LMARG+basesPerLine], &s, 7);
         /* and drop in the sequence directly after it. */

         if (block_Cnt != block_repeat) k = basesPerLine; /* test for end of sequence to end gracefully */ 
         else k = (int)seq_len - (block_Cnt-1)*basesPerLine;
         if (flags[5] != 1) { /* if the sequence is a subsequence, print the #s of the original seq too */
            /*write the correct numbering in Left margin  */
            sprintf(s, "%7d",((int)(((block_Cnt-1)*basesPerLine)+flags[5]))); /* these 2 lines could be combined...? */
            memcpy(&O_txt[O_SEQ_LINE+1][0], &s, 7);
            /* and in the right margin - combine with the above bit? */
            sprintf(s, "%7d",(int)(((block_Cnt)*basesPerLine - 1 + flags[5])));
            memcpy(&O_txt[O_SEQ_LINE+1][O_LMARG+basesPerLine], &s, 7);
         }

         memcpy(&O_txt[O_SEQ_LINE][O_LMARG], &sequence[(block_Cnt-1)*basesPerLine+BASE_OVERLAP+1], k); 
         /* and need to use the "s" intermediate here because Rev_Compl doesn't return the pointer to 
         the converted string, although it probably should... */
         Rev_Compl(sequence+BASE_OVERLAP+1+((block_Cnt-1) * basesPerLine), s, k);
         /* and then plunk the converted sequence into O_txt with a similar statement */
         memcpy(&O_txt[O_SEQ_LINE+1][10], &s, k /*basesPerLine*/ );

         /* write out the minor and major tics below the reverse complement */
         tic_line = O_SEQ_LINE+2;
         for (i=0;i<(int)(basesPerLine/10);i++) memcpy (&O_txt[tic_line][i*10+O_LMARG],"    ^    *",10);

      /* This would be the place for the *ORFMAP* call - has to be placed in an if/else branch with the bit below */

         /* Following call to Translate has to calculate the # of bases at each call; otherwise end up with 
            overrun condition at end; "k" in code above */
         if (n_letters != 0) {
            for (mm=0;(mm<(int)Xn && mm<3); mm++) {
               if (k % 3 != 0) k = ((int) k /3)*3;   /* also added this code to Translate() for better modularity */
               seq_offset = ((block_Cnt-1)*basesPerLine+BASE_OVERLAP+1);
               Translate(sequence+seq_offset+mm, Prot_out, k, n_letters, Codons, codon_Table); 
               /* need to place the translation frame labels here before memcpy() call */
               sprintf(ctemp1, "%d", mm+1);   O_txt[O_SEQ_LINE+3+mm][0] = ctemp1[0];
               memcpy(&O_txt[O_SEQ_LINE+3+mm][O_LMARG+mm], &Prot_out, k); /* and copy it into place */
               if (Xn == 6) { /* but if it's 6 frames of Xlation, need to do oppo at the same time */
                  Anti_Par (sequence+seq_offset-mm, s, k); /* get the *antipar* sequence */
                  Translate (s, Prot_out, k, n_letters, Codons, codon_Table); /* Xlate it into N-letter code */
                  if (n_letters == 1) Reverse (Prot_out); /* to match the 'backwards' DNA strand */
                  else Triplet_Reverse (Prot_out);
                  /* need to place the translation frame labels here before memcpy() call */
                  sprintf(ctemp1, "%d", mm+4);   O_txt[O_SEQ_LINE+6+mm][0] = ctemp1[0];
                  memcpy(&O_txt[O_SEQ_LINE+6+mm][O_LMARG-mm], &Prot_out, k); /* and copy it into place */
               }
            }
         }

         /* This 'while' loop tests each text block for REs and also prints out those blocks that have no 
         cuts in then at all but which have to be printed anyway....*/
         while ((DD->Dat[DCnt] != -2) && (base_real_pos < ((block_Cnt * basesPerLine) + BASE_OVERLAP))) {
            DCnt++; 
            /* if we're not at the end and the real pos'n <  current block + the overlap.. */
            /* !! Now DD->Dat[DCnt] should point to the corresponding  RE #  */
            
             /* if following test is true (they're !=) then it's safe to write it; */
             /* if it's false, then the same proto has already written to the same space */
            if (BackCheck[DD->Dat[DCnt]] != DD->Dat[DCnt-1]) { /* if !=, do this, but 1st... */
               BackCheck[DD->Dat[DCnt]] = DD->Dat[DCnt-1];  /*  ... set it = so that it won't do this one again */
               okline = O_SEQ_LINE-2;
               
          /* !!! this next line has to be checked very carefully - is it referencing the right RE el?  Looks like it */
               Cur_RE = (int)DD->Dat[DCnt];
               block_cut_pos =  (int)base_real_pos - 1 - ((block_Cnt-1) * basesPerLine); /* see if it's this easy?! */
   
               /* Now locate it in the block, checking for under- and over-runs */
               if (block_cut_pos >= 0) { /* if the position is greater than the beginning of the block */
                  if (block_cut_pos <= basesPerLine) { /* and if it's less than the end of the block... */
                     abcp = O_LMARG + block_cut_pos - 1; /* abcp = adjusted block_cut_pos - used x times below */
                     O_txt[O_SEQ_LINE-1][abcp] = '\\';   /* write the 'cut' indicator */
                     /* locate the position for writing the name */
                     while (block_cut_pos < ok2wr[okline]) okline--; /* then go up to the lowest 'free' line */
                     if (okline != O_SEQ_LINE-2)  { /* but if can't place the name on the lowest line.. */
                        i = O_SEQ_LINE-1; k = 0;   /* check if there's any space lower between previous names */
                        /* following 'while' must be ordered like it is - i will be decr only if k == 0 */
                        while (k == 0 && --i != okline) { /* leaving 1 space before and after the name */
                           if (O_txt[i][abcp-1] == ' ' &&                /* this can be replaced with something */
                               O_txt[i][abcp+RE[Cur_RE].E_nam_l] == ' ' &&  /* more efficient later */
                               O_txt[i][abcp+3] == ' ' &&       /* must check for a space here... */               
                               O_txt[i][abcp+4] == ' ' )  k = 1;  /* as well as here */
                             /* i = vertical counter ~= okline, k = 1 when we find enuf space */
                        }
                        okline = i;
                     }
                     if (okline < 2) {
                        fprintf(stderr, "!! Output Buffer Blown around base %ld - degeneracy caused too many Enz's\n"
                           "to be matched!! Increase the stringency of Enz selection w/ -n -o -M flags\n", base_real_pos);
                        exit(1);
                     }
                     /* and memcpy the RE name from the struct to the output array */
                     memcpy (&O_txt[okline][abcp],&RE[Cur_RE].E_nam, RE[Cur_RE].E_nam_l);
                     /* and incr the ok2wr posn for that line by the length of the RE name + 1 */
                     /* 'ok2wr[okline]' below is modified only if we didn't find any lower spaces */
                     if (block_cut_pos+RE[Cur_RE].E_nam_l+1 > ok2wr[okline]) {
                        ok2wr[okline] = block_cut_pos+RE[Cur_RE].E_nam_l + 1; 
                     }
                  } /* if (block_cut_pos < basesPerLine).. */
                  else {  /* otherwise it's in the overlap area from the next block */
                     if (in_OL == -1) {   /* if this is the 1st time in OVERLAP, mark it */
                        in_OL = 1;        /* by setting in_OL to 1  */
                        Cnt_reset = DCnt - 1;  /* Have to back up to 1st RE in the OVERLAP that did not 
                                                         resolve into the current block */
                     }   /* The above marker *should* back the DCnt to the position of the Cur_RE */ 
                  }
               }     /* if (block_cut_pos >= 0) ... */
   
               base_real_pos = DD->Dat[++DCnt]; /* make sure that this is set before the next loop */
               if (okline < min_okline) min_okline = okline;
            } else {
            /* fprintf(stderr, "\t!!BackCheck Matched at BASE %d; RE[%d](%s)\n", DD->Dat[DCnt-1], DD->Dat[DCnt], RE[DD->Dat[DCnt]].E_nam); */
               base_real_pos = DD->Dat[++DCnt]; /* this gonna fix it? */
            }
         }  /*  while (DD->Dat[..... */

         /* Now print out the block we've composed, from min_okline to MAX_OUTPUT_LINES */
         for (i=min_okline; i<max_okline;i++) fprintf(stdout, "%.*s\n",p_width,O_txt[i]);
         fflush(stdout);  /* and fflush the fucker each time ?!??!!? - works, but why?? */

         /* And clean out the lines written into O_txt as well */
         memset(O_txt,' ',((O_LMARG + O_RMARG + MAX_BASES_PER_LINE) * MAX_OUTPUT_LINES));  /* set all of O_txt to blanks */
      }   /* for (block_Cnt=1; block_Cnt<block_repeat; block_Cnt++) ... */
   } /*    if (flags[20] == 1) ... ie if you want a linear map ofthe sequence */
   
	/* Following allows mutiple analyses to be appended without getting them all mixed up*/
   fprintf(stdout, "\n ==--------------------------  End of Analysis  --------------------------==\n\n\n");

   /* And (please) give Harry an electronic citation automatically, spitting all the relevant info   */
/* back to hornet - should include program version, sequence lenth (seq_len, not tot_seq_Cnt),    */
/* options via flagvalue, which cpu, OS, date, error state if definable, others in */
/* one long string via udp packets */
#if REPORT == 1
   if (flags[15]==1)  {
  /* copy the version and command-line args into the progname var to send back via udp */
      sprintf(progname, "[TACG Version %s] ", VERSION);
      for (i=0; i<argc; i++) {
         strcat(progname, argv[i]);
         strcat(progname, " ");
       }
       sprintf(s, " <%ld bp>", seq_len);
       strcat(progname, s); 
       i = iamhere(progname); /* if citation flag is 1 then spit the udp packets */
   }
#endif
} /* End main() */

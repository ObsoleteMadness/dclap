
#if  defined(__MWERKS__) || defined(THINK_C)  || defined(MPW)
#define MACINTOSH 1    /* compile with ChildAppj.c -- dgg */
#endif
										
										
/*...And The Small Print Taketh Away...

COPYRIGHT NOTICE (taken almost verbatim from James Knight's common-sensical 
----------------  declaration about code usage from his estimable 'seqio' 
                  library, parts of which are soon to be incorporated into 
                  this program.

    Copyright (c) 1996 by Harry Mangalam at Univ. of California, Irvine

    Permission to use, copy, modify, and distribute this software and its 
    documentation is hereby granted, subject to the following restrictions
    and understandings:

      1) Any copy of this software or any copy of software derived
         from it must include this copyright notice in full.

      2) All materials or software developed as a consequence of the
         use of this software or software derived from it must duly
         acknowledge such use, in accordance with the usual standards
         of acknowledging credit in academic research.

      3) The software may be used by anyone for any purpose, except
         that its redistribution for profit or inclusion in other
         software sold for profit requires the express, written
         permission of the author.  Note that the written permission
         of the author is not required for any use of the software
         that may result in profit, and the author waives any rights
         to any part of profit gained by any use other than
         its redistribution for profit.
 
         In plain English, the only thing that requires the express,
         written permission is if you want to sell software that
         includes or uses this software.  Any use other than selling
         software that uses this software is fine, and any profit made
         from that use is yours to keep.

      4) This software is provided AS IS with no warranties of any
         kind.  The author shall have no liability with respect to the
         infringement of copyrights, trade secrets or any patents by
         this software or any part thereof.  In no event will the
         author be liable for any lost revenue or profits or other
         special, indirect and consequential damages. 
*/



/* Defines */     
#define VERSION "2.35f"  /* PLEASE DON'T CHANGE THIS #define - I NEED THIS INFO TO BE ABLE TO GATHER STATS ON USAGE */
                         /* version of the program - one of the vars to be returned via udp */
#define REPORT 0     /* directs the inclusion (1) or exclusion (0) of the UDP reporting code */
#define MAXSITE 50 /* max length of site - may not need if do use pointer math intelligently */
#define MAX_NUM_RES 1000  /* Max number of REs that we'll accept for text output routines - will later*/
                          /* be taking some of these from the command line - may be made archaic by dynamic mem*/
#define INIT_RES 300        /* Initial # of REs for use in dynamic mem allocation */                      
#define RE_INCR 200     /* the size by which RE is increased at each step */
#define BASE_OVERLAP 30 /* # of bases past the end of a block in order to 'trap' REs whose cut offset put them 
                        into block - was 20, see if it works at 30 - yes!  Also used in topology routines as the 
                        amount that needs to be added to beginning and end of sequence to allow 'trapping'  
                        as above, if DNA is circular */                  
#define MAX_BASES_PER_LINE 210   /* the max allowable output width; need it to be able to decl and init man arrays*/
                                 /* placeholder until can grab basesPerLine from flags to set wanted output width */
#define O_SEQ_LINE 70         /* # of line in MAX_OUTPUT_LINES where the sequence gets writ; should be about MAX_OUTPUT_LINES - 10 */
#define MAX_OUTPUT_LINES 80   /* max # of lines per block - also influences how many blank lines go after 
                              the data at each block; was 25, now incr to 80 to allow 6 frames of translation and all the REs you could imagine */
#define O_LMARG 10            /* left margin in text output */
#define O_RMARG 10            /* right margin in text output */
#define MAX_ORGS 8            /* number of different Codon Usage tables */
#define N_CODONS 64           /* number of codons - this would ever change???? */
#define NFLAGS 41             /* number of flags (size of flags[] array) */
#define MAX_LADGEL_WIDTH 250  /* # chars to print out the ladder/gel map - obv only use if use a v. compr font */
#define PREFERED_NUM_DIVS 10  /* # of major divisions in the ladder map */
#define TIC_REPEAT 4          /* after this many lines should the tics be repeated in the ladder map */
#define NUMBERLINE_REPEAT 20  /* after this many lines should the number header be repeated in the ladder map */
#define SUMMARY_CUTS 0        /* this many # cuts is the cutoff for the summary map - if set to 0, then it will
                                            be calculated so that >10000 bases, you'll get log(seqlen)-2 cuts reported 
                                            if set to a # > 0, it will stay statically at that number  */
#define RE_NAME_TAB_SIZ 521   /* the (prime) size of the hashtable for handling the RE Names - */
#define MAX_SEL_ENZ 20        /* max number of enzymes that can be selected from the commandline */
#define MAX_DEGEN 256         /* max degeneracy that can be in the keying hexamer for the degenerate cutting fn() */
#define ALRDY 100                   /* size of already[] in Cutting() and HorribleAccounting() */
#define MAX_PP 10                   /* max # of proximity pattern relationships */
#define MAX_ERR 5                   /* max # errors allowed in a sequence for -p, -P - 5th term in a REBASE entry */

 struct RE_struct {
   char E_nam[10],      /* RE name */
        *E_raw_sit,     /* RE name with the ' and _ and all n's included for a label, if needed */
        *E_wsit[2],     /* RE whole recognition site, minus _ ' trailing n's */
        E_hex[2][7]; /* the hexamer(+1 for term) extracted from E_wsit, used to generate the hash key */
    int E_tcut[2],   /* the cut site on the top strand, relative to the besthexindex calc'ed in BestHexWWPal()
                                the val from REBASE is read into this var when the line is read, but is then 
                                adjusted to the correct val in BestHexWWPal() a bit later.  When the best 
                                hex was simply the 1st 6mer it was exactly the raw value read in from the 
                                REBASE, but since th ebest hex is calculated (chiefly for non-RE patterns), 
                                it also has to be calculated */
        E_olap,     /* the overlap if any in the cut- dif between the top cut and bottom cut */
        E_len,      /* the length of the recognition sequence */
        E_pal,          /* whether or not the recognition sequence is a palindrome */
        E_dgen,         /* degeneracy in the recognition sequence */
        E_Ncuts,        /* the # of cuts that the RE causes in the sequence */
        E_mag,          /* the magnitude of the degeneracy - acgt=1; n=0; yrmkws=1/2; b,d,h,v = 1/4, etc */
          WW[2],            /* Which Way - # that indicates which way Degen_Cmp has to go to do a complete comparison */
          proto,            /* the prototype RE entry for the list of degenerated names for ERRORs */
          Err,          /* Errors allowed in the sequence, entered from cmdline or from mod to REBASE entry */
          E_nam_l;      /* the length of the name (E_nam, above) for calcing the  name positions in output */
   long *Sites,     /* list of hit sites for the DNA for each enzyme - was separate (Dig_Sits) */
      *Frags;       /* list of fragments for the DNA for each enzyme - was separate (Frag_sits) */
 }; 

/* ORFs is a 2D array of type struct that keeps the orfs found in each fram
separate.  The problem in 
   doing it in this way (as opposed to one continuous stream of orfs) is that I
   have to keep track of 
   which frame and keep mallocing mem as I find more orfs.  */

 struct ORF_struct {
   int frame;           /* what frame it is */
   long  B_offsetAA;    /* Beginning and ending offset from aa 0 in same frame in aas */
   long  E_offsetAA;    /* Beginning and ending offset from aa 0 in same frame in aas */
   long  B_offsetBP;    /* Beginning and ending offset from aa 0 in same frame in bps */
   long  E_offsetBP;    /* Beginning and ending offset from aa 0 in same frame in bps */
   int   orflength;     /* duh... */
   char  *orf;          /* the orf itself in UPPER case, single character form */
   float MolWt;         /* in KD */
};  /* use a pointer to it and then keep mallocing more mem as needed?  I think so ...  this 
                makes it 6 wide (for sep frames and then indiv ORFs can be appended to the array by 
                mallocing more mem */

 struct Digest_Data {   /* Replacement for Dig_Dat and associated vars, the easier to pass to functions */
    long BOS;  /* used to be BOS, now just incorporated into this stuct for compactness */
    long EOS;  /* used to be EOS, ditto */
    long *Dat; /* What used to be Dig_Dat - hold all the raw cutting data */
                    /* particularly evil as the 1st 2 elements now hold Cnt [0] and Siz[1], so all writes and
                        reads for actual data have to start at el [2] */
};

 struct Prox_struct {
    short upstr,    /* whether N1 is upstream or downstream of N2 */
            gt;     /* whether the dist is greater than or less than Dlo */
    int REi[2], /* the RE index corresponding to the names */
            matchlen; /* how long the below *matches is, for easier use by succeeding fn() */
    long    range,  /* diff between Dlo and Dhi */
            *matches,/* variable sized array that holds the matches between N1, N2 */
            Dlo,        /* Distance between N1,N2; if there is a Dhi, then Dlo is the lower
                            bound on the distance */
            Dhi;        /* If present, places an upper limit on the distance; also obviates '.gt' */
    char    st,     /* = search type - one of 9, depending on the diff combos of flags, using it as pseudo-int */
            *optline, /* the orig option line for the -P flag that generated the results */
            *N[2];  /* holder for Names of the factors */
};


/* Declaring this global simplifies a great deal of the variable passing and bookkeeping for mem pointers */

/*
extern struct RE_struct *RE;
extern struct Prox_struct PP[];
extern struct Digest_Data *DD;
extern struct ORF_struct *ORFs[];
*/

extern struct RE_struct *RE;
extern struct ORF_struct *ORFs[6];
extern struct Digest_Data *DD;
extern struct Prox_struct PP[10];

extern long *Dig_Dat;
extern char *sequence;
extern long flags[NFLAGS];
extern char *optarg;
extern int optind, opterr, optopt;

/***********************  Function Prototype Declarations for tacg  ************************/

/* fill_out_sum duplicates the degeneracy the correct # of times in the array 'sum[]' for submission 
   to the hash function */
void fill_out_sum(int degen, int N_degen, int dgn_sits[]); 

/* palindrome func returns 1 if the sequence is a pal, 0 if it's not  */
int palindrome(char *site, int length);

/* hash() is a central function to this program - feel free to improve it.  It takes a 
(possibly degenerate) n-mer (most often a hexamer) sequence and calculates the hash value 
from (for a hexamer) 0 (=aaaaaa) to 4095 (=tttttt) */
int hash(char *nmer, int dgn_sits[], int num_bases);

/* Degen_Cmp compares a degenerate DNA seq with a non degenerate sequence;  
   returns 1 if they're compatible, 0 if not */
int Degen_Cmp(char *pattern, char *target, int length, int mode, int WW);

/* Rev_Compl returns the Reverse Complement of the original sequence */
/* if original = ggatcatttc, reverse complement = cctagtaaag */
void Rev_Compl(char *original_seq, char *reverse_complement, int length);

/* Anti_Par returns the anti parallel sequence of the original sequence */
/* if original = ggatcatttc, anti parallel = gaaatgatcc */
void Anti_Par(char *original_seq, char *anti_parallel, int length);

/*  Function reverse; straight from K+R (p62) - reverses a string s in place  */
/* if original = ggatcatttc, reverse = ctttactagg */
void Reverse(char *s);

/* Function Triplet_Reverse reverses a string triplet by triplet ie:
   ArgTrpPheAsnCys ==> CysAsnPheTrpArg  so as to make the 6 frame translations readable in the oppo
   orientation */
void Triplet_Reverse(char *str);

/* Translate translates (nondegenerate, for now) DNA sequence into protein sequence, using 
    one of 8 codon preferences */
void Translate(char *DNA_in, char *Prot_out, int len, int n_letters, char *Codons[8][64], int organism);  

/* Read_Codon_Prefs reads in the file that has the codon preferences in human-readable form
   then hashes the codons and inserts them into the right place in the Codon arary.  The file also has a 
   description line for each table that is read into a char array for labelling purposes. */
/* void Read_Codon_Prefs(char *Codons[8][64], char *Codon_Labels[]); */

int iamhere(char *progname);   /* from udping.c */

/* SetFlags() takes argc/argv and a bunch of variables that hold all the option values and 
   implements the routines to read them in and does most of the error checking.  It's related functionally 
   to Interactive(), which it calls, and to CommandLine(), which makes use of these flags to compose a 
   commandline argument which can be used then next time instead of going thru Interactive(). */
char *SetFlags (int argc, char *argv[], char SelEnz[MAX_SEL_ENZ][11], FILE *tmpfp);

/* Usage() spits out some useful info about how to use the program if it's invoked incorrectly or 
   without flags*/
void Usage(void);

/* compare is a dippy little function that qsort needs to perform its sordid little sort */
int compare(const void *n1, const void *n2);

/* GetSequence reads and formats the sequence from **stdin** and returns the address of the read-in 
   sequence, as well as length of the sequence, along with the bracketing repeats - needs only a 
   few extra variables to do it and it cleans up main considerably */  
char *GetSequence(long *tot_seq_Cnt, long *seq_len);    

/* PrintSitesFrags prints out the sites and or fragments either sorted or unsorted, depending on whether the 
   array has been sorted - it doesn't care, it just prints whatever's in the array nicely */
void PrintSitesFrags(int NumGREs, int reps, int *GREs, int sites);

/* PrintGelLadderMap does what it implies - prints a Gel and/or Ladder map sort of like the GCG program, 
   but in textmode only for now.  It uses a preset (#defined) output width of ~200 chars, vs the regular  
   output which is settable via a flag.  This being the case, it writes to a user-selectable file, rather 
   than to stdout.  The output is meant to be processed by an postscript wrapper program like genscript, 
   so that the output can be printed landscape in small font to be usable.
   This is one of my mulitvalent functions that wil process either Sites or Fragments depending on a 
   mode switch (gel) and the data fed it - perhaps not such a great idea... 
   In this fn(), if it's called with gel=1, it will want Fragment data (RE[].Frags)
   If it's called with gel=0 (ie make a ladder) it will want Sites data */
void PrintGelLadderMap(int NumGREs, long seq_len, int *GREs, int gel);

/* SearchPaths () takes a filename and examines various environment variables to locate that filename.  
If it can find the file, it returns a pointer to the full path name; if not, it returns NULL  */
char *SearchPaths(char *InputFileName, char *FileType4Err);

/* realhash() is a real hashing function, straight from Sedgewick (p233) 
   that returns a good hash value within the scope of the allocated space, 
   because of the mod() tablesize MUST be prime for reliable results */
unsigned realhash(char *string2hash, int tablesize);

/* MatchSelREs() takes RE names and (typically,m if there was a hash collision, determines if it was a real 
   match or just a random collision; returns a 0 if no match, 1 if a true match */
int MatchSelREs(char *suspect, char SelEnz[MAX_SEL_ENZ][11], int NumSelREs);

/* DownCase() downcases all the letters in the submitted string  */
char *DownCase(char *string);

/* ReadREs does just that - given a filename (EnzFileName), it tries to open it and if successful, reads all the 
   uncommented REs into the global RE[] struct, and then returns the # of entries in RE (NumREs).  
   Matching against the SELECTED REs specified on the command line takes place after this functions 
   returns.  Besides some random declarations that have to be cleaned out, doesn't deal with the 
   GRE arrays or indices - they are restricted to main(), from which this code chunk was was excavated.
   It returns a pointer to hashtable which is an important array for the Coutting routines */
int ReadEnz(char *EnzFileName, FILE *tmpfp, int *NumREs, char SelEnz[MAX_SEL_ENZ][11], int *hashtable[4096]);

/* DegenCut() is a functionization of the cutting routines needed to do the cutting analysis on 
   degenerate (gyrwsctkmyycg) sequence - also uses HorribleAccounting() as a function.  This fn() 
   includes routines for both 'lite' and 'heavy' degenerate cutting, where lite is defined as ignoring 
   any key hexamer which has ANY degeneracy and 'heavy' will force degenerate matching of any degeneracies 
   up to a compiled in limit (currently 256 = 4 ns (or equivs) out of the keying hexamer) */
void Cutting(char *sequence, int *hashtable[4096]);

/* HorribleAccounting() is a function that became one simply becasue it contains common code for the cutting 
   functions mentioned above.  If it turns out to be about as fast as the inline code, I'll functionize it in 
   NonDegenCut() as well - OK , did it */
void HorribleAccounting(char *sequence, int Key, int mode, int *hashtable[4096], long CSP/* , int already[]*/);
   
/* NonDegenCut() is a functionization of the routine needed to do the cutting analysis on 
   nondegenerate (pure - gctagctgac) sequence - uses  HorribleAccounting(), as well */
/* long *NonDegenCut(char *sequence, int *hashtable[4096], struct Digest_Data DD); */

/* ORF_Analysis() does what it implies - analyzes the ORFs found - have to hand it the translated sequence
   (*prot), it's length (protlen), anf the frame (thisframe) and it finds and calculates the stats on all 
   the ORFs above the cutoff size (flags[11]) */
void ORF_Analysis(char *prot, long protlen, short thisframe);

/* ORF_Calcs() does the actual calculations for the analyses; so far just the molwt calc  
   'ORFNum' is the current orf number and 'f' is the frame  */
void ORF_Calcs(int ORFNum, int f);

/* little fn() that farts the ORF data to stdout - only reason to keep it separate from ORF_Analysis is
    that I'll probably be adding the ORF Map function to ORF_Analysis and this will keep it a tad more modular */
void PrintORFs(int ORFNum, int frame, int MinORF);

/* Degen_Calc() is a sleazy little fn() to calculate the degeneracy of the hexamer (possibly later, 
    any string) without the added overhead of the other stuff in hash() that also does this */
int Degen_Calc(char *s);

/* this little sucker returns the 'magnitude' of the string given it as per the same parameters as hash()  */
float MagCalc(char *s, int len);

/* BadMem() just writes a message and calls exit() */
void BadMem(char* message, int exitcode);

/* Proximity() does all the proximity matching for the patterns detected in the search phase.  Takes
    care of it's own output */
void Proximity(void);

/* BadFlag just warns the user of a badly constructed flag, points to where more info
	can be got, and exits */
void BadFlag(char *flag);


/* dgg -- replacement for unixism getopt() */
int myGetopt(int argc, char** argv, char* opts);
extern char* myOptarg; /* any option argument */
extern int atarg;      /* set = 0 to reuse myGetopt */


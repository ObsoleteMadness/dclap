/* Program tacg - a command line tool for Restriction Enzyme digests of DNA  */
/* Copyright � 1996, 1997 Harry J Mangalam, University of California, Irvine (mangalam@uci.edu, 714 824 4824) */

/* The use of this software (except that by Harald T. Alvestrand, which is described in 'udping.c')
   is bound by the notice that appears in the file 'tacg.h' which should accompany this file.  In the event 
   that 'tacg.h' is not bundled with this file, please contact the author.
*/
#include <ctype.h> 
#include <string.h> 
#include <stdlib.h>
#include <math.h>
#include <time.h>
/*#include <sys/stat.h> - not needed now, dgg*/
#include <unistd.h>
#include <stdio.h>
#include "tacg.h" /* contains all the defines, includes, function prototypes for both main() and functions */


/* SetFlags() takes argc/argv and a pointer to SelEnz[][] (array that holds the names of the Enz's selected 
   from the command line and implements the routines to read them in and do the error checking.  
   It returns a pointer to the name of the Enzyme file name.
   Yes, I know there are far too many options.... */


/* Don't pay too much attention to this upper comment - this is a running notepad to myself, partially describing
   most of the flags, some inaccurately...*/

   /* flag_val contain the letters and values of the option flags */
   /* Here are the delarations from tacg.c for reference */
/*    index                   0   1   2   3       4   5   6   7   8   9  10  11  12  13  14  15  16  17  18  19  20  21  22  23  24  25   */
/*    flag_letter       =   {'f','n','o','m',    'M','b','e','g','l','t','T','O','v','h',' ','c','r','R','C','F','L','s','w','H','c','V'}; */
/*    flags              = {{ 1,  4,  1,  1,  32000,  0,  0,  0,  0,  1,  0, -1, -1, -1, -1,  0, -2, -2,  0, -1,  1,  0, 60,  0,  0,  0 }, changed values */
/*                          { 1,  4,  1,  1,  32000,  0,  0,  0,  0,  1,  0, -1, -1, -1, -1,  0, -2, -2,  0, -1,  1,  0, 60,  0,  0,  0 }};   static values */

   /*   0   topo,     -f : for *form* (= topology) - 0 (zero) for circular; 1(d) for linear */
   /*   1   magCuts,  -n : magnitude of RE; upwardly inclusive - 4(d) = all, 5 = 5,6..., 6 = 6,7...  */
   /*   2   overHang, -o : overhang - 5, 3, 0 for blunt, 1(d) for all */
   /*   3   minCuts,  -m : minimum # cuts to be considered; 1(d) for all */
   /*   4   MaxCuts,  -M : Maximum # cuts to be considered; 32,000(d) */
   /*   5   boSubseq, -b : beginning of DNA subsequence; 0(d) for normal beginning  */
   /*   6   eoSubseq, -e : end of DNA subsequence; 0(d) for normal end  */
   /*   7   gel,      -g : include gel map summary - 1 to include; 0(d) to exclude
                           - probably not going to be done for 1st release */
   /*   8   ladder,   -l : ladder map include with graphics above; 1 to include; 0(d) to exclude  */
   /*   9   trans1,   -t : translate with 1 letter codes; 1(d), 3, 6 to incl w/ that many frames of translation; 
                           0 to exclude  */
   /*  10   trans3    -T : translate with 1 letter codes; 1, 3, 6 to incl w that many frames of translation -  
                           0(d) to exclude; -t and -T are of course mutually exclusive.  */
   /*  11   ORF table -O : table of ORFs in the form '-O frameframeframe,minORF' ie -O 135,55
                           which indicates that you want ORF data from frames 1, 3, and 5 with a min ORF length
                           of 55 amino acids  */
   /*  12   ver       -v : asks for version of the program (no numeric argument) */
   /*  13   help      -h : brief help page (no numeric argument) */
   /*  14   ignore    -i : consider input seq degenerate, but ignore if key hexamer has any degenerate bases 
                                (mainly for LOTS of degenerate seq, as in rough maps where Kbs might be n's) */
   /*  14   degen     -d : consider input seq degenerate AND do extended POSSIBLE mapping even if key hexamer 
                                                                is degenerate.  Shows all possible hits.  use with caution. */
   /*  14   Degen     -D : consider input seq degenerate AND do extended EXACT mapping even if key hexamer 
                                                                is degenerate (mainly for slightly degenerate sequence, as in unverified/1st pass 
                                                                sequence where you want to generate maps but can't be sure of a few bases) */
   /*  15   quiet     -q : be quiet (don't cite) 1(d - cite) or 0 (don't cite, swine) by udp */
   /*  16   EnzSel    -r : for interactively selecting specific REs (-r enz,enz,enz,enz,enz)  */
   /*  17   REBASE    -R : indicate an alternative rebase name */
   /*  18   CodonUse  -C : Codon Usage table to use for translation: 0(d) to 7 */
   /*  19   Fragments -F : Fragment data to include/exclude; -1(d) if not defined, 0 : no fragment data, 
                           1 : unsorted by size, 2 : sorted by size, 3 : both sorted and unsorted  */
   /*  20   LinearMap -L : whether to print linear map; 0 : don't print the map, 1(d) print the map. */
   /*  21   sites     -S : whether to print cutsites; 0(d) : don't print cutsites, 1 : print cutsites */
   /*  22   width,    -w : number of characters wide to print out results - has to be in multiples of 15, from
                           60(d) to 210 bps per line */
   /*  23   HTML      -H : if 1, output includes HTML headers, minimal at this point */
   /*  24   by cuts   -c : if 1, sort output by # cuts per enzyme, like Strider */ 
   /*  25   Verbose   -V : if 1, be chatty (otherwise, no std err output, for scripting) */
   /*  26   Summary   -s : flag to print out the summary section - cuz don't want summary every time */

/* the 2 below have not been implemented yet, of course */
   /*  ??   pattern   -p : '-p name,pattern,err' - command line entry of patterns to search for  */
   /*  ??   Proximity -P : '-P name1,[+-<>]distance,name2' - Proximity matching for 2 patterns (from a file).  Can be 
                             repeated up to 10 times for 10 relationships
                             name1, name2 - names of the 1st and 2nd sequence sites
                             + indicates that name2 is downstream of name1; default is either 
                             - indicates that name2 is upstream   of name1; default is either
                             g indicates that name2 is greater than (or equal to) 'distance' from name1
                             l indicates that name2 is less    than (or equal to) 'distance' from name1    */
   /* 40    io				whether any output flags have been set so far - at least one needs to be for there to be any output..*/

char *SetFlags (int argc, char *argv[], char SelEnz[MAX_SEL_ENZ][11], FILE *tmpfp) {
                             
   char s[80], ch;
   char *temp = "             "; /* temp holder for RE name in the selection string */
   char *patt = "                                                                                                    "; /* for the pattern */
   char *NMess = "                              ";
   char *RebFile;    /* holder for alternative Rebase file string */
   int   i, j, m, e, f, max, err=0, len, mid,
   		optlen,  /* len of the optarg string */
         SECnt=0, /* for SelEnz */
         pCnt=0,  /* for patterns */
         PPCnt=-1,    /* for PP - Pattern Prximity struct entries, st at -1 cuz it incr at start of stanza  */
         c;    /* holder for the 1st char past the '-' (flag indicator) - has to be of type int because of getopt */
   FILE *fppat;      
	struct tm *date;
	/* struct stat statrec; -not needed now,dgg*/
	time_t now;
      /* in args below, single letters indicate single letter opts; those followed by colons have further args
        some of which have to be parsed by strtok() and stuffed into the appro array  */

      while ((c = myGetopt(argc, argv, "chHlLqsSvVb:C:D:e:f:F:g:G:m:M:n:o:O:p:P:t:T:r:R:w:")) != EOF) {
  
      	switch(c) { /* switch based on the letter after the '-' */

         default:   fprintf(stderr, "\n\"%c\" - Unrecognized or Unimplemented Flag!!!\n", c); break;

         case 'f':  /* form or topology  - circular or linear */
         if (myOptarg == 0) BadFlag("-f"); /* die on bad flag */
         switch (myOptarg[0]) {
            case '0': case '1': flags[0] = atoi(myOptarg); break;
            default:  {
               fprintf (stderr, "'-f' flag requires '0' (circular) or '1' (linear).  Assuming linear \n"); 
               flags[0] = 1;
               break;
            }
         } 
         break;

        /* 'R' uses SearchPaths() to search for an alternative rebase file - SearchPaths() checks if 
            the name starts with a '/','~', or '.' and uses the full path and name if entered 
            without leading path specifiers, else checks thru a series of paths depending on 
            environment variables and returns the pathname of whatever it finds.  If SearchPaths() 
            finds nothing, it returns NULL and everything dies */
         case 'R': 
         	if (myOptarg == 0) BadFlag("-R"); /* die on bad flag */
            if (flags[17] == 2) {
               fprintf(stderr,"!! '-p and -R flags are incompatible.  Continuing with values from '-r'.\n");
            } else {
               flags[17] = 1; /* mark it so I can reconstruct the command line */
               if ((RebFile = SearchPaths(myOptarg, "REBASE" /* , flags*/ )) == NULL) {
                  fprintf(stderr,"Can't find the alternative REBASE file!! - Check spelling, ownership, existance, etc - Bye!!\n");
                  exit(1);
               } 
               flags[29]=2; /* set -p flag so that it won't be used */
            }
         break;
         
         /* -p flag needs 3 storage parts: eg:  -p Name,gattgcnnnrygts,1
       	1) the name (same length as the regular names (10+\0).  As written, it creates or appends 
       		a REBASE style entry to the file name 'tacg.patterns', as well as a temp file that is processed 
       		exactly as rebase.data - this both prevents more contention for SelEnz and decreases the 
         	amount of supporting code and creates a record of the things you've been looking for.
         2) the pattern - written to the files as described above
         3) the number of ERRORs allowed in searching for these patterns.  This will cause another var to 
         	be writ to these files - the # of errors allowed and requires another step to detect it 
         	in ReadEnz(), but it should still allow most of the pre-existing code to run unmodified.
         	This also allows the REBASE entries to be modified by appending this ERROR number to the data
         	part of the line ie:
        			hjm	   2 gcgggtswnnnnnt  0 ! anything after the '!' is ignored
        			becomes
        			hjm	   2 gcgggtswnnnnnt  0 2 ! where the 2 is the max number of errors tolerated.
        			
        		in ReadEnz(), the sequences corresponding to the errors are generated on the fly, checked 
        		against each other, and if novel, added to RE, with the mod that the (new) RE entry 'proto'
        		refers all hits by this sequence to the prototype 
      	*/

         case 'p':  /* include patterns from the command line, sharing some of the vars from the -r flag above */
         	if (myOptarg == 0) BadFlag("-p"); /* die on bad flag */
            if (flags[29] != 2) { /* go thru this only if -R hasn't been set */
               
            if (strlen(myOptarg) < 3) { /* check if there's something in myOptarg */
               fprintf(stderr, "!! '-p' flag option is too short or missing.  The '-p' flag usage is:\n"
               "'-p name,pattern,error'; repeat as needed for more patterns.\n");
               exit(1);
            }
            flags[17]=2; /* warning to -R flags[] element to prevent possible contention */
      
            /* if (stat("tacg.patterns", &statrec) != 0) */
            if ((fppat= fopen("tacg.patterns","r")) == NULL) /* is a bit more ansi -- dgg */
            {
            	 fclose(fppat);
           	/* if pat file doesn't exist, write header */
               fppat = fopen("tacg.patterns","a+"); /* open/create file to log patterns created this way */
               if (fppat == NULL) { fprintf(stderr,"!!tacg.pattern open failed - que??\n"); exit(1); }
               fprintf(fppat, "Created by 'tacg -p name,pattern'. This file is a log of the patterns entered\n"
                           "from the command line.  They are in REBASE format and can be edited into other\n"
                           "such files if you wish.\n"
                           "..\n");
               pCnt++;
            } else if (pCnt++ == 0){ /* then the file exists but this is the 1st time thru, so just open the
                                          pre-existing file for appending */
               fppat = fopen("tacg.patterns","a+b"); 
               if (fppat == NULL) { fprintf(stderr,"!!tacg.pattern open failed - que??\n"); exit(1); }
            } /* and if pCnt is > 0, then this is the 2nd or more time thru, so just keep adding to the file */
            
            /* break myOptarg into separate chars and plunk into SelEnz[i][10] */
            temp = DownCase(strtok(myOptarg, ",")); 	/* 1st call initializes strtok() */
            patt = DownCase(strtok(NULL, ",")); 	/* further calls continue to break it up */
            if (strlen(patt)>BASE_OVERLAP) {
            	fprintf(stderr, "In '-p' option, pattern must be < %d bases - truncating + continuing.\n", BASE_OVERLAP);
            	patt[BASE_OVERLAP] = '\0'; 
            }
            err  = atoi(strtok(NULL, ",")); 		/* ditto */
            if (err<0) {
            	fprintf(stderr, "In '-p' option, error term must be > 0 - assuming 0 and continuing.\n");
            	err = 0; 
            }
            if (err>MAX_ERR) {
            	fprintf(stderr, "In '-p' option, error term must be < %d - assuming %d and continuing.\n", MAX_ERR, MAX_ERR);
            	err = MAX_ERR; 
            }
            
      /* compose and print out the strings to both the temp and pattern files */
            time(&now);    					/* Get the current calendar time.   */
            date = localtime(&now);  		/* Convert it to a readable date .   */
            strftime(s, 80, "%c", date); 	/* Convert that to a string.     */
            mid = (int) (strlen(patt) / 2); /* calc the ~midpt of patt so that the hit indicator will be ~centered */
            
            fprintf(tmpfp, "%s  %d  %s  0  %d ! Pattern added @ %s\n", temp, mid, patt, err, s); /* print to temp file */
            fprintf(fppat, "%s  %d  %s  0  %d ! Pattern added @ %s\n", temp, mid, patt, err, s); /* and to the pattern log */
            flags[29] = 1; /* and set the flags[] element */
            flags[37] = err; /* use flags[37] to carry the error var as well */
            } else {
               fprintf(stderr, "!! '-p' flag incompatible with already set '-R' flag; \n"
                           "continuing with '-R' value.\n");
            }
         break;         

         /* the SelEnz[] also used by -P to filter enz's from REBASE; ergo -r and -P are incompatible */
         case 'r':  /* process comma-delimited list into a char *array and return that to main() as well */
         	if (myOptarg == 0) BadFlag("-r"); /* die on bad flag */
         	if (strlen(myOptarg) > 1 && flags[30] == 0) { /* check if there's something in myOptarg and !using -P */
               /* break myOptarg into separate chars and plunk into *SelEnz[10] */
               temp = DownCase(strtok(myOptarg, ",")); /* 1st call initializes strtok() */
               SECnt = 0; max = MAX_SEL_ENZ;     /* shouldn't have to do this, but it failed otherwise */              
               while (temp != NULL && SECnt < max) {
                  temp = DownCase(temp);  /* lclint says this is not kosher, but tracing it looks ok */
                  strcpy(SelEnz[SECnt], temp); SECnt++;
                  temp = (strtok(NULL, ","));
               }
               if (SECnt >= max) fprintf(stderr, "'-r' flag has too many names; using only the 1st %d\n", max);
               flags[16] = 1;
            } else { /* whine about a badly composed enz name string */
               fprintf(stderr, "The '-r' flag usage is '-r enz,enz,enz...'; try again\n");
               exit(1);
            }
         break;
         
         /*            vv-dep--|------|      */
         /* -P N1,[+-][lg]#####[-#####],N2    where ##### are non negative #s  */
         /*      ^|-----  NMess  -----|^     */
         case 'P': /* here we go - the final frontier - pattern proximity matching */
         	if (myOptarg == 0) BadFlag("-P"); /* die on bad flag */
         	flags[40] = 1; /* set flags[40] to indicate that some outout has been requested */         
         	optlen = strlen(myOptarg);
            if (optlen > 5 && PPCnt < MAX_PP && flags[16] < 0) { /* check if there's something in myOptarg 
               and haven't done too many and don't conflict with '-r' */
               e=f=0; PPCnt++; flags[16] = -1; flags[30]++;/* reset e,f; incr the P, flags[30] counter */
               /* break myOptarg into separate elements - the 2 names and then the NMess */
               /* going to have to use the '-r' procedure, if not all the data structures to match the REBASE names */
               /* Some initializations for those vars that need it */
               PP[PPCnt].upstr=0;
               PP[PPCnt].gt =-1; 		/* 'less than' is the default */
               PP[PPCnt].range =-1;  	/* NO range is the default */
			
               /* grab the command line string for attaching to the output */
               PP[PPCnt].optline = (char *) calloc(optlen+1, sizeof(char));
               if (PP[PPCnt].optline==NULL) BadMem("calloc fails at optlen", 1);
               strcpy(PP[PPCnt].optline, myOptarg);
               
               /* co-opt the '-r' SelEnz[] for this one as well */               
               temp = DownCase(strtok(myOptarg, ",")); /* 1st call initializes strtok(); returns 1st token */
               len = strlen(temp);
               if (len > 10) {
               	fprintf(stderr, "In '-P' option, name %s is too long, truncating to 10 chars.\n", temp);
               	temp[10] = '\0';
               	len = 10;
               }
               PP[PPCnt].N[0] = (char *)calloc(len+1, sizeof(char));
               if (PP[PPCnt].N[0] == NULL) BadMem("!calloc fails\n", 1);
               strcpy(PP[PPCnt].N[0],temp);
               strcpy(SelEnz[SECnt++], PP[PPCnt].N[0]);
               if (PP[PPCnt].N[0]==NULL) fprintf(stderr,"Bad format in '-P' flag.\n");
               
               NMess = strtok(NULL, ","); /* gets the Number Mess */
               if (NMess==NULL) fprintf(stderr,"Bad format in '-P' flag.\n");
               
               temp = DownCase(strtok(NULL, ",")); /* gets the 2nd name */
               len = strlen(temp);
               if ( len > 10) {
               	fprintf(stderr, "In '-P' option, name %s is too long, truncating to 10 chars.\n", temp);
               	temp[10] = '\0';
               	len = 10;
               }
               PP[PPCnt].N[1] = (char *)calloc(len+1, sizeof(char));
               if (PP[PPCnt].N[1] == NULL) BadMem("!calloc fails\n", 1);
               strcpy(PP[PPCnt].N[1],temp);
               strcpy(SelEnz[SECnt++], PP[PPCnt].N[1]);
               if (PP[PPCnt].N[1]==NULL) fprintf(stderr,"Bad format in '-P' flag.\n");
               
            /* so now have myOptarg broken into usable tokens */
               len = strlen(NMess); /* how much pain is there? */
               j = 0;
               for (i=0;i<len;i++) {
                  switch (NMess[i]) {
                     case '+': 
                        if (i== 0) PP[PPCnt].upstr = -1; /* can only be used once at start */
                        else fprintf(stderr,"'+' out of place in '-P' option\n");
                     break;
                     
                     case '-':
                        if (i==0) PP[PPCnt].upstr = 1; /* can only be used in this context once at start */
                        else { /* indicates the end of Dlo, so process it as a decent # */
                        	temp[j] = '\0';
                        	PP[PPCnt].Dlo = abs(atoi(temp));
                        	f = -1; memset(temp, 0, 13); j = 0; /* re/set the related vars */
                        	if (PP[PPCnt].gt != 0) {
                           	fprintf(stderr,"in '-P' option 'l or g' illegal when specifying a range\n"
                                          	"unsetting it and continuing...\n");
                           	PP[PPCnt].gt = 0;
                        	}
                        }
                     break;
                     
                     case 'l':
                        PP[PPCnt].gt = -1;
                        if (i>1) fprintf(stderr,"'l' out of place in '-P' option, but continuing...\n");
                     break;
                     
                     case 'g':
                        PP[PPCnt].gt = 1;
                        if (i>1) fprintf(stderr,"'g' out of place in '-P' option, but continuing...\n");
                     break;
                     
                     case '0': case '1': case '2': case '3': case '4': 
                     case '5': case '6': case '7': case '8': case '9': 
                        temp[j++] = NMess[i]; /* must be part of one of the distances, so add it */
                     break;
                     
                    default: fprintf(stderr,"Bad char (%c) in '-P' option.\n", NMess[i]);
                    break;
                  }
               }
               temp[j] = '\0';  /* regardless */
               if (f == -1) {
                  PP[PPCnt].Dhi = abs(atoi(temp)); /* if f= -1, this is the *2nd* number.. */
                  PP[PPCnt].range = abs(PP[PPCnt].Dhi - PP[PPCnt].Dlo); /* the range of the distances */
               } else {
                  PP[PPCnt].Dlo = atoi(temp);   /* else it's the 1st */
                  PP[PPCnt].range = -1; /* -1 indicates NO range */
               }
               /*set the searchtype here, rather than decide on the fly later */
               if (PP[PPCnt].upstr==0) {  
                  if (PP[PPCnt].gt==-1) {
                     if (PP[PPCnt].range==-1) PP[PPCnt].st = '0';   /* upstr:0 gt:-1 range:-1 - default*/
                  } else if (PP[PPCnt].gt==1) PP[PPCnt].st = '1';   /* upstr:0 gt: 1 range:-1 */
                     else  						 PP[PPCnt].st = '2';   /* upstr:0 gt: 0 range:calc */
               } else if (PP[PPCnt].upstr==1) {
                  if (PP[PPCnt].gt==-1) {
                     if (PP[PPCnt].range==-1) PP[PPCnt].st = '3';   /* upstr:1 gt:-1 range:-1 */
                  } else if (PP[PPCnt].gt==1) PP[PPCnt].st = '4';   /* upstr:1 gt: 1 range:-1 */
                     else  						 PP[PPCnt].st = '5';   /* upstr:1 gt: 0 range:calc */
               } else if (PP[PPCnt].gt==-1) {
                     if (PP[PPCnt].range==-1) PP[PPCnt].st = '6';   /* upstr:-1 gt:-1 range:-1 */
                  } else if (PP[PPCnt].gt==1) PP[PPCnt].st = '7';   /* upstr:-1 gt: 1 range:-1 */
                     else 					 		 PP[PPCnt].st = '8';   /* upstr:-1 gt: 0 range:calc */
                     
               if (strcmp(PP[PPCnt].N[0], PP[PPCnt].N[1]) == 0) PP[PPCnt].upstr = 0; /* if same, there is no 'upstream' */
            } /* if (strlen(myOptarg) > 1 && PPCnt < MAX_PP) { ...  */
         break;
         
         case 'c':  /* sort REs in output by # cuts; by order of listing in REBASE if not */
            flags[24] = 1;
         break;
         
         case 'F': /* How to present fragment data - include or exclude 0-3; it's -1(d) (no frag data) if it wasn't called*/
         	if (myOptarg == 0) BadFlag("-F"); /* die on bad flag */
         	flags[40] = 1; /* set flags[40] to indicate that some outout has been requested */
            j = atoi(myOptarg); 
            if (j>=0 && j<4) flags[19] = j;
            else fprintf (stderr, "The '-F' flag value must be: \n"
            "           0 (don't print fragment data), \n"
            "           1 (print fragments sorted by order)\n"
            "           2 (print fragments sorted by size), or \n"
            "           3 (print fragments sorted both ways), \n"
            "not \'%s\'.\n", myOptarg);
         break;

         case 'D':  /* consider input seq degenerate AND do extended mapping even if key hexamer is degenerate */
         	if (myOptarg == 0) BadFlag("-D"); /* die on bad flag */
            j = atoi(myOptarg); 
            if (j>=0 && j<5) flags[14] = j;
            else fprintf (stderr, "The '-D' flag value must be: \n"
            "           0 (FORCE exclusion of IUPAC and other characters in sequence), \n"
            "           1 (default - cut as nondegenerate unless IUPAC characters found; then cut as '-D4')\n"
            "           2 (allow IUPAC characters; ignore them in the KEY hexamer, but match outside of KEY)\n"
            "           3 (allow IUPAC characters; find only exact matches)\n"
            "           4 (allow IUPAC characters; find ALL POSSIBLE matches)\n"
            "not '%s'.\n", myOptarg);
         break;

         case 's': /* print summary stats of enz's that don't map and how many times they do if any */
         	flags[40] = 1; /* set flags[40] to indicate that some outout has been requested */
            flags[26] = 1;
         break;

         case 'H':  /* include HTML tags if present, exclude if not */
            flags[23] = 1;
         break;

         case 'O': /* sets which ORFs to analyze and minimum ORF length */
      		if (myOptarg == 0) BadFlag("-O"); /* die on bad flag */
	         flags[40] = 1; /* set flags[40] to indicate that some outout has been requested */
	         memset(s,' ',80);
            if (strlen(myOptarg) > 2) { /* check if there's something useful in myOptarg */
               /* break myOptarg into separate args and plunk into frames[] */
               i=0; j=31; /* j starts at 30 to make the frames to be ORFed fit in flags[] correctly */
               while (myOptarg[i] != ',' && myOptarg[i] != '\0') {
                   /* have to make the individual char a string 1st */
                   s[0] = myOptarg[i]; s[1] = '\0';
                   m = atoi(s);
                   if (m > 0 && m < 7 && j < 37) { /* as long as m values are OK and we haven't gone up too far */
                     flags[j++] = m; /* flags passes frame-2b-ORFed indicators (NOT nec in order) */
                   } else {
                      fprintf(stderr, "'-O': frames have to be between 1 and 6 inclusive; try again\n");
                      exit(1);
                   }
                   i++;
               }
               if (myOptarg[i++] == ',') {
                strcpy(s,myOptarg+i);
                m = atoi(s); /* this should now a properly terminated string */
                if (m > 0) flags[11] = m; /* store the value in the '-O' position in flags */
               } else { /* we got here becuz we hit '\0' before getting the min ORF value */
                fprintf(stderr, "'-O' flag is missing the Min ORF length value - try again\n");
                exit(1);
               }
            } else {
                fprintf(stderr, "'-O' flag usage is '-O frameframeframe,MinOrfLength';\n"
                "ie. '-O 135,55' (data from frames 1,3,5 with a minimum ORF length of 55 aas - try again\n");
            }
        	break;

         case 'n':  /* magnitude of RE recognition site - 4 cutter, 5 cutter, etc */
		      if ((int)myOptarg == 0) {
		      	BadFlag("-n"); /* die on bad flag */
		      }
		      
            j= atoi(myOptarg);
            if (j>2 && j<11) flags[1] = j;
            else {
               fprintf (stderr, "'-n' flag requires an integer between 3 and 10.  Assuming '-n6'..\n");
               flags[1] = 6;
            }
         break;

         case 'o':  /* Type of overhang to consider - omit flag to consider all */
		      if (myOptarg == 0) BadFlag("-o"); /* die on bad flag */
            j = atoi(myOptarg); 
            if (j==5 || j==3 || j==1 ||j==0) flags[2] = j;
            else  fprintf (stderr, "'-o' flag must be 5, 3, 1, or 0; omit to include all overhangs...Assuming all\n");
         break;  /* above assumption doesn't require changing anything */

         case 'G':  /* Graphics data - argument is the number of bases per bin,format */
		      if (myOptarg == 0) BadFlag("-G"); /* die on bad flag */
         	flags[40] = 1; /* set flags[40] to indicate that some outout has been requested */
         	temp = DownCase(strtok(myOptarg, ",")); /* 1st call initializes strtok(); returns 1st token */
            len = atoi(temp); /* len = Nbins */
            if (len > 0) flags[38] = len;
            else {
            	fprintf (stderr, "'-G' flag option (part1) must be 0 or greater.\n");
            	exit(1);
            }
				temp = (strtok(NULL, ",")); /* next call gets second argument */
				len = strlen(temp);
				if (len == 1) {
					temp = DownCase(temp);
					ch = temp[0];
					if (ch == 'x') flags[39] = 1;
					else if (ch == 'y') flags[39] = 2;
					else if (ch == 'l') flags[39] = 3;
					else {
						fprintf(stderr, "Bad option for '-G'\n");
						exit(1);
					}
				} else {
					fprintf(stderr, "-G flag option (part 2) must be in form '-G Bin_size,X|Y|L'\n");
					exit(1);
				}				
         break;

         case 'm':  /* Minimum # of cuts to be considered */
		      if (myOptarg == 0) BadFlag("-m"); /* die on bad flag */
            j = atoi(myOptarg); 
            if (j>=0) flags[3] = j;
            else fprintf (stderr, "'-m' flag must be 0 or greater.\n");
            if (flags[4] != 0 && flags[4] -j < 0) {
               fprintf (stderr, "'-m' flag (%d) must be less than or equal to '-M' flag (%ld)."  
               " Assuming you want all cuts.\n", j, flags[4]);  /* Doesn't require changing anything */
            }
         break;

         case 'M':  /* Maximum # of cuts to be considered */
		      if (myOptarg == 0) BadFlag("-M"); /* die on bad flag */
            j = atoi(myOptarg); 
            if (j>=0) flags[4] = j;
            else fprintf (stderr, "'-M' flag must be 0 or greater.\n");
            if (flags[3] != 0 && j - flags[3] < 0) {
               fprintf (stderr, "'M' flag (%d) must be greater than or equal to 'm' flag (%ld). "
               "Assuming you want all cuts.\n", j, flags[3]);
            } 
         break;

         case 'b':  /* Beginning of subsequence */
		      if (myOptarg == 0) BadFlag("-b"); /* die on bad flag */
            j = atoi(myOptarg);
            if (j>0) flags[5] = j;
            else  {
                fprintf (stderr, "'-b' flag (%d) must be >0.\n", j);
                exit(1);
            }
            /* check if b < e and that sequence is long enough (>4) */
            if ((flags[6] != 0) && (flags[6] - j < 4)) { 
               fprintf (stderr, "'-b' flag (%d) must be less than value of '-e' flag (%ld)\n "
                                 "and subsequence must be at least 4 bps", j, flags[6]);
               exit(1);
            }  
         break;

         case 'e':  /* End of subsequence */
		      if (myOptarg == 0) BadFlag("-e"); /* die on bad flag */
            j= atoi(myOptarg); 
            if (j>0) flags[6] = j;
            else  {
               fprintf (stderr, "'-e' flag must be > 0.\n");
               exit(1);
            }  
         /* check if e > b and that sequence is long enough (>4) */            
            if ((flags[5] != 1) && (j - flags[5] < 4)) { 
                fprintf (stderr, "'-b' flag (%d) must be less than value of '-e' flag (%ld)\n "
                                 "and subsequence must be at least 4 bps", j, flags[6]);
                exit(1);
            } 
         break;

         /* 'g' - include the gel map; currently a text/graphic, width-settable with -w flag  */
         /* flag has 1 argument: '-g minlog', where minlog = some exponenent of 10 and indicates 
            where the gel should start - no longer just 10 or 100 - can be ANY exponent of 10 */
         case 'g':  
		      if (myOptarg == 0) BadFlag("-g"); /* die on bad flag */
         	flags[40] = 1; /* set flags[40] to indicate that some outout has been requested */
            j = atoi(myOptarg);            
            if (j >= 10){
               flags[7] = (long)log10((double)j); /* truncates to the integer part */
            } else {
               fprintf (stderr, "The '-g' flag form is: '-g #' (where # >= 10); assuming -g100 \n");
               flags[7] = 2; /* 2 = log10(100) */
               exit (1);
            }
         break;

         case 'l': /* include the ladder map; currently a text/graphic, set with -w, same as everything else */
         	flags[40] = 1; /* set flags[40] to indicate that some outout has been requested */         
            flags[8] = 1;
         break;

         case 't': /* Translate in 1 letter code in 1, 3, or 6 frames */
		      if (myOptarg == 0) BadFlag("-t"); /* die on bad flag */
            j = atoi(myOptarg);
            if (j==0 || j==1 || j==3 || j==6)  {
               flags[9] = j;
               flags[10] = 0; /* Exclude the 3 letter option */
            } else fprintf (stderr, "'-t' flag option must be 1, 3, or 6, not %s.\n"
                                     "   Will use the default and continue...\n", myOptarg);
         break;

         case 'T':   /* Translate in 3 letter code in 1, 3, or 6 frames */
		      if (myOptarg == 0) BadFlag("-T"); /* die on bad flag */
            j = atoi(myOptarg);           
            if (j==0 || j==1 || j==3 || j==6)  {
               flags[10] = j;
               flags[9] = 0; /* Exclude the 1 letter option */
            } else {
                fprintf (stderr, "'-T' flag option must be 1, 3, or 6, not %s.  "
                                 "   Will use the default value (1) and continue...\n", myOptarg);
                flags[10] = 1;
                flags[9] = 0; /* Exclude the 1 letter option */
            }
         break;

         case 'h': 
            Usage(); 
            exit(1);
         break;

         case 'v':
            fprintf (stderr, "program tacg, Version %s, Copyright�1996,1997 Harry Mangalam (mangalam@uci.edu),"
            "UC Irvine\n", VERSION);
            exit(1);
         break;

         case 'q': /* quiet - don't cite Harry (Swine!) */
               flags[15] = 0;
               fprintf (stderr, "You've chosen the no-citation option (-q); please reconsider next time!\n");
         break;

         case 'V': /* Verbose - print error messages to stdout; otherwise shaddup */
               flags[25] = 1; 
         break;

         case 'C': /* Codon usage table to use - 0(d) to 7 */
		      if (myOptarg == 0) BadFlag("-C"); /* die on bad flag */
            j = atoi(myOptarg);
            if (j>=0 && j<8) flags[18] = j;
            else  {
               fprintf (stderr, "'-C' flag value must be between 0 and 7, not %s.\n", myOptarg);
               Usage(); /* let user see what the values are */
               exit(1); /* and then die */
            }
         break;

         case 'L': /* whether to print linear map; -L prints the linear map; omitting it doesn't print it */
         	flags[40] = 1; /* set flags[40] to indicate that some outout has been requested */         
            flags[20] = 1;
         break;

         case 'S':  /* whether to print cutsites; if specified, print cutsites; otherwise don't */
         	flags[40] = 1; /* set flags[40] to indicate that some outout has been requested */
            flags[21] = 1;
         break;

         case 'w': /* change the output width */
		      if (myOptarg == 0) BadFlag("-w"); /* die on bad flag */
            j = atoi(myOptarg);   
            if (j<60 || j>210)  {
               fprintf (stderr, "'-w' value must be between 60 and 210; program truncates to a \n"
               "number exactly divisible by 15 (178 would be truncated to 165).\n");
               exit (1); /* and die cleanly */
            }  else flags[22] = (int) j / 15*15; /* recalc for every value given by flag to cut down on retries */
            /* and so it's passed back to main(); replaces the BASES_PER_LINE #define */
         break;
      }   /* end of switch() statement */
   }  /*    while (--argc > 0 && (*++argv)[0] ... */
   if (pCnt != 0){ /* only if it's been opened can we close it, dummy */
      fclose(fppat); /* close the pattern log; temp file pointer stays open until end of ReadEnz() */
   }
   return RebFile;
}    /* end of  SetFlags */

void BadFlag(char *flag) {
	fprintf(stderr, "The %s flag requires a value after it - please try again.\n", flag);
	fprintf(stderr, "Type 'tacg -h' for a brief description of the flags, 'man tacg' for more.\n");
	exit(1);
}


/* Program tacg - a command line tool for Restriction Enzyme digests of DNA  */
/* Copyright � 1996, 1997 Harry J Mangalam, University of California, Irvine 
   (mangalam@uci.edu, 714 824 4824) */

/* The use of this software (except that by Harald T. Alvestrand, which is described in 'udping.c')
   is bound by the notice that appears in the file 'tacg.h' which should accompany this file.  In the event 
   that 'tacg.h' is not bundled with this file, please contact the author.
*/
#include <stdio.h>
#include <ctype.h> 
#include <string.h>
#include <stdlib.h>
#include "tacg.h" /* contains all the defines, includes, function prototypes for both main() and functions */


/* this horrible bit of rubbish is another of the ilk of HorribleAccounting() - nasty, but common code that
	is being sent off to the penal colony of a separate function so it won't contaminate the morals and 
	elegance of the rest of ReadEnz() - returns the 'magnitude' of the string given it */
float MagCalc(char *s, int len) {
   float fmag = 0; /* float counter for magnitude */  
   int i;
   for (i=0;i<len;i++){ /*for each base in the site ...*/
      switch (s[i])  { 
         default: fprintf (stderr, "Strange character in MagCalc() : %c\n", s[i]); break;
         case 'a': case 'c': case 'g': case 't': fmag += 1; break;
         case 'y': case 'r': case 'm': case 'k': case 'w': case 's': fmag += 0.5; break;
         case 'b': case 'd': case 'h': case 'v': fmag += 0.25; break;
         case 'n':  break; /* 'n' doesn't cause the mag to be increased at all */
      } 
   }
   return fmag;
}


/* GetSequence reads and formats the sequence from stdin and returns the length of the sequence, as well as a pointer
   to the array that holds it (*sequence) along with the bracketing repeats - needs only a few extra variables to do it
   and it cleans up main considerably. begin and end are indices to the real world coordinates of the sequence */
/* tot_seq_Cnt    length of sequence + bracketing overlaps
   seq_length     actual number of bases read
   
   HEY!! wouldn't it be great to allow embedded comments - all text inside of [...] is ignored
   but who would do such a weirdly non-standard thing?
   
*/
char *GetSequence( long *tot_seq_Cnt, long *seq_length ) {
   long eoseq = 30000, m, j, l, seq_len, seq_Cntr=1, begin = 1, end = 1000000000, totSeqCnt;
   int  c, realloc_iter = 0, f1=0;
   char *sequence, ct, blank[BASE_OVERLAP+1];   
   memset(blank, 'a', BASE_OVERLAP+1);

/* Get mem for sequence */
sequence = (char *) calloc (30000, sizeof(char));  /* init the pointer to 30,000 */
if (sequence == NULL) BadMem("initial calloc for sequence", 1);

/* load the sequence array, filtering as we go */
   totSeqCnt = BASE_OVERLAP + 1; /* to allow the wrapped seq to be inserted before the real seq 
                                    (and to allow real seq to start at x1) */
   begin = flags[5];  /* set in SetFlags() */
   if (flags[6] != 0) end = flags[6];    /* Ditto */

   while (
   	(c = getchar()) != EOF) 
   	&& (c < 255) /* dgg -- a hack fix for msdos-java which ain't sending EOF thru stdin pipe */
   	{ /* new - stdin-oriented;  */
   	
      if (eoseq - totSeqCnt <10){
         sequence = (char *)realloc(sequence, sizeof(char)*(eoseq+30000));
         if (sequence == NULL) BadMem("realloc sequence", 1); /* this does not pass realloc_iter... */
         eoseq = eoseq + 30000;
         realloc_iter++;
      }
   /* Now real seq will start at 'BASE_OVERLAP'; before that is wrapped seq from the end and at the end is 
      wrapped seq from the beginning - required to handle circular seqs */
      ct = tolower(c);
      if (ct == 'u') ct = 't'; /* converts u's to t's */
   /* no longer need if/else decision for different modes - slightly slower this way but more compact and better
      user interaction ...? */
      switch (ct) {
         case 'a': case 'c': case 'g': case 't': /* favored 4 always get added */
            if (seq_Cntr++ >= begin) sequence [totSeqCnt++] = ct;   /* add it to the sequence */
            if (seq_Cntr > end) goto gotAllSeq; /* nasty but efficient way to break out of loops*/
         break;
         
         case 'r': case 'y': case 'w': case 's': case 'k': case 'm':
         case 'b': case 'd': case 'h': case 'v': case 'n':  /* but if it's a valid IUPAC code */
            if (flags[14] > 0) {
               if (flags[14] == 1) { /* 1 = default so maybe user forgot to set it */
                  flags[14] = 3; /* 3 = old -D flag; this should only visited once */
                  if (flags[25] == 1) fprintf(stderr, "\nIUPAC degeneracies in sequence - assuming '-D3'. \n"
                     "Type 'tacg -h' for brief description or 'man tacg' for more info.\n");
               }
               if (seq_Cntr++ >= begin) sequence [totSeqCnt++] = ct;   /* add it to the sequence */
               if (seq_Cntr > end) goto gotAllSeq; /* nasty but efficient way to break out of loops*/
            } else if (flags[25] == 1) { /* if verbose */
               if (f1++ == 0) {
                  fprintf(stderr, "\n!! NONdegenerate input mode '-D0', but the following valid IUPAC\n"
                  "characters are in the sequence (from headers, sequence, embedded comments, etc):\n");
               }
               if (ct != '\n' && ct != ' ') fprintf(stderr, "%c ", ct);
            }
         break;
         
         default:  /* bad char detect'n but if not acgt we don't count it and don't care - */
            if (flags[25] == 1) { /* unless we're being verbose, so spit bad chars to stderr */
               if (f1++ == 0) fprintf(stderr, "Bad characters: ");
               if (ct != '\n' && ct != ' ') fprintf(stderr, "%c ", ct);
            }
         break;
      }  /* end of switch/case statement */
   }  /* at this point 'totSeqCnt' should point just past the end of the sequence */

   gotAllSeq: /* fast exit point */
   seq_len = totSeqCnt-BASE_OVERLAP-1; /* value to return to main() */


/* The following code performs the "pad the beginning sequence with the end and the end with the beginning"
   regardless of whether it's the whole sequence or a subsequence, using the vars 'begin'  and 'end' */ 

/* and now pad out the beginning w/ the end and the end w/ the beginning of sequence[]  */
/* I'm using 'BASE_OVERLAP' cuz it'll change if some RE is found with a longer recog seq offset*/
/* l = index in  sequence' indicating absolute starting point for seq to be cut; 
      starts at BASE_OVERLAP+1 (just past the buffer) if no subsequence chosen.  If a subseq was specified, 
      it should be bumped up by the amount of 'begin', the user's idea of where the cut should start
      m = increment up to BASE_OVERLAP
      begin = beginning of the seq to be cut from the user's point of view.
      end = ending point for seq to be cut from the user's point of view.; 
      was seq_len or totSeqCnt if no subsequence chosen */

   if (seq_len < BASE_OVERLAP)  { /* if it's a v short seq, pad it with junk */
      memcpy(&sequence[0], &blank, BASE_OVERLAP+1);   /* pad the beginning with a's */
      memcpy(&sequence[totSeqCnt], &blank, BASE_OVERLAP+1);  /* pad the back with a's */
   } else { /* else do the std tango of copy the end to the begin; begin to the end */
      for (l=BASE_OVERLAP+1,m=0; l <= BASE_OVERLAP*2+2 && m <= BASE_OVERLAP; l++,m++)  {  
         sequence[totSeqCnt+m] = sequence[l]; /* copies seq past the end from the the beginning */
      }  /* note that in the above 'for', 'totSeqCnt' itself doesn't change */

      for (j=BASE_OVERLAP+1,m=0; j >= 0 && m <= BASE_OVERLAP; j--,l++,m++)  {  
         sequence[m] = sequence[totSeqCnt-j]; /* copies seq to before the beginning from the end */
      }  /* note that in the above 'for', 'totSeqCnt' itself doesn't change */
   }

   if ((flags[5] != 1 || flags[6] != 0) && flags[25] == 1) fprintf(stderr, "\nSubsequence is %ld bases.\n", seq_len);

   totSeqCnt += BASE_OVERLAP;
   sequence[totSeqCnt+1] = '\0';  /* and term the sequence string, then decr it to point to end of the seq  */
   /* and free the mem not used by the sequence string */
   sequence = realloc(sequence, sizeof(char)*(totSeqCnt+1));
   /* sequence is padded with extra bases to allow circular cutting, but anything that depends on DNA length
      will reference the specific variable 'seq_len' */

   /* now we have the sequence in one long string, with 'BASE_OVERLAP' bp buffers at each end, so cut it as 
      overlapping hexamers, starting at sequence[0], but only record cuts in the real seq */
   *tot_seq_Cnt = totSeqCnt; /* send it back to main() ... a greenie weenie way to do it */
   *seq_length = seq_len;       /*     ditto     */
   return sequence;  /*  return the address of sequence ) */
}   /* End of GetSequence() */



/* Degen_Calc ia a sleazy little fn() to calculate the degeneracy of the hexamer (possibly later, any string) 
        without the added overhead of the other stuff in hash() that also does this but also makes uncomfortable
        calls to other more fragile functions */
        
int Degen_Calc(char *s) {
   int i, f1=0, TotDegen=1;
   for (i=0;i<6; i++) {
      switch(s[i]) {
         case 'a': case 'c': case 'g': case 't':    break; /* no increase in degeneracy */
         case 'y':case 'r': case 'm': case 'k': case 'w': case 's': TotDegen *= 2;  break;
         case 'b': case 'd': case 'h': case 'v':   TotDegen *= 3; break;
         case 'n':  TotDegen *= 4; break;
         default:  /* bad char detect'n  */
            if (flags[25] == 1) { /* if we're being verbose, spit bad chars to stderr */
               if (f1++ == 0) fprintf(stderr, "Degen_Calc: Bad chars: ");
               fprintf(stderr, "%c ", s[i]);
            }
         break;
      }
   }
return TotDegen;
}


/* SearchPaths () takes a filename and examines various environment variables to locate that   
   filename. If it can find the file, it returns the full path name; if not, it returns NULL */

char  *SearchPaths (char *InputFileName, char *FileType4Err){

   int i, File_Found, VERBOSE;
   char *FileToFind, *tacglib;
   static char *Env_Vars[] = {"PWD",     "$PWD (Current Directory)",
                              "HOME",    "$HOME (Home Directory)", 
                              "TACGLIB", "$TACGLIB (TACG library)"};
   VERBOSE = (int)flags[25]; /* set VERBOSE */
   FileToFind = (char *) calloc (150, sizeof(char)); 

/* specify an alternative input file - this is constructed so that if the name starts */
/* with a '/', '~', or  '.' , assume it's a valid path name; otherwise 1st look in */
/* $PWD, then in $HOME, then in $TACGLIB */

/* 1st, see if it can be opened without any searching, regardless of what it starts with */
   strcpy(FileToFind, InputFileName);  
   if ((fopen(FileToFind,"r")) != NULL) { /* grab and check the next entry as the alt rebase file name */
   if (VERBOSE==1) fprintf(stderr,"Found %s file \"%s\"!!\n",FileType4Err, FileToFind);
    File_Found = 1; 
  } else {  /* see if it's in either in the current directory $PWD (1st) $HOME (2nd) or $TACGLIB (3rd) */
      /* is it in $PWD ? */
      i=0;
      while (i < 5) {
         tacglib = getenv(Env_Vars[i++]);
         if (tacglib != NULL) { 
            strcpy(FileToFind, tacglib); /* should overwrite FileToFind with tacglib */
            strcat(FileToFind, "/"); /* to allow strcpy'ing the path and the file together correctly */
            strcat(FileToFind, InputFileName); /* copy the file name in behind it */
            if ((fopen(FileToFind,"r")) == NULL) { /* if ! here, print err and check next env var */
               if (VERBOSE==1) fprintf(stderr,"Hmmm.. %s file \'%s' not found in %s.\n", FileType4Err, FileToFind, Env_Vars[i]);
               File_Found = 0;   
               i++;                                       
            } else {
               if (VERBOSE==1)  fprintf(stderr,"Found alternative %s file '%s' in %s.\n",FileType4Err, FileToFind, Env_Vars[i]);
               i=100; File_Found = 1;
            }
         } else if (VERBOSE==1)  fprintf(stderr, "Hmmm... %s isn't defined so I can't find it there!\n\n", Env_Vars[i++] );
      }
   }

   if (File_Found == 0) FileToFind = NULL;
   return FileToFind;
}   /* End of SearchPaths ()   */


/*  compare is a dippy little function that qsort needs to perform its sordid little sort */
int compare(const void *n1, const void *n2 ){
        return ( *((int *) n1) - *((int *) n2) );
}


/********************************  Function Translate  *****************************

Translate() takes as input a pointer to a string of nondegenerate **OR degenerate**
DNA and returns the translated sequence as protein in either 1 or 3 letter 
code in either 3 letter spacing or 1 letter spacing (for generating full length 
protein strings.  
For degenerate sequences, it's pretty dumbassed - if there's a degenerate base
in the triplet, it'll just ignore the sequence and move on.

Will translate according to a number of translation tables stored as 
3D array of pointers in Codons [organism][codon][label].  The coordinate 
points to a char string that holds the single letter xl at pos '0' and the 
3 letter xl starting at pos 1.  Does not do 3 frame translation - have to 
do 3 calls to it for that.  Also, does not do any output formatting - have 
to handle that in the print section...  JUST translates.  However, will 
truncate the translated string to the correct length if not a multiple of 3

**********************************************************************************/

void Translate (char *DNA_in, char *Prot_out, int len, int n_letters, char *Codons[8][64], int organism) {
   /* DNA_in   pointer to the DNA seq that needs to be translated, typically the entire DNA array,
               with the correct offset PREcalculated so that the pointer refers to the correct start
               site
      Prot_out pointer to the array that is filled by Translate() in either 1 or 3 letter code,
               typically passed to the print routines to be instantly printed out.
      len      the length of the DNA sequence to be translated
      n_letters   codes the number of letters of the aa label and the spacing: 
               1 - A  L  H  V
               2 - ALHV
               3 - AlaLeuHisVal
      Codons   array that holds all the codon preference data for the different organisms or mitos
               loaded by subroutine Read_Codon_Prefs() in tacg.xf.c from external file "codon.prefs"
               that has to be in the same dir as program currently.
      organism var that indicates which organism's codon prefs should be used for this translation
   */

   int sum[256], i, j, prot_len;
         char XXX[3] = {'X','X','X'};

   if (len % 3 != 0) len = ((int) len /3)* 3;   /* round len to a multiple of 3 */
   prot_len = len;
   if (n_letters == 2) prot_len = len/3;  /* and div by 3 if we're creating the compact form of translation */
   memset (Prot_out,' ',prot_len); /* set Prot_out to blanks */
   for (i=0,j=0; i<len && j<len; i += 3,j++) {  /* for the length of the DNA sequence */
      if (hash(DNA_in+i, sum, 3) == 1) {    /* hash the next triplet; if it's nondegenerate... */
        if (n_letters == 1)  { /* single letter, triple spacing for sub-DNA labeling */
            Prot_out[i] = Codons[organism][sum[0]][0]; /* look up the correct value and plunk it into the output */
        } else if (n_letters == 2)  {  /* single letters, with single spacing */
            Prot_out[j] = Codons[organism][sum[0]][0]; 
        } else { /* triple letters, triple spacing for sub DNA labeling */
            memcpy (&Prot_out[i], &Codons[organism][sum[0]][1],3); /* or memcpy the 3 letter code over */
        }
      } else {
        if (n_letters == 1)  { /* single letter, triple spacing for sub-DNA labeling */
            Prot_out[i] = 'X'; /* look up the correct value and plunk it into the output */
        } else if (n_letters == 2)  {  /* single letters, with single spacing */
            Prot_out[j] = 'X'; 
        } else { /* triple letters, triple spacing for sub DNA labeling */
            memcpy (&Prot_out[i], &XXX,3); /* or memcpy the 3 letter code over */
        }

      }
   }
   /* and be sure to terminate it correctly */
   if (n_letters == 2) Prot_out[j] = '\0';
   else Prot_out[i] = '\0';
}  /* End of Translate()  */


/*********************************  Function Anti_Par  ********************************
*   Anti_Par takes 2 char pointers, the 1st to the original seq, the 2nd to the       *
*   seq that it generates that is the reverse complement, and the length of the seq   *
*   to consider.                                                                      *
**************************************************************************************/

void Anti_Par (char *ori, char *anti, int len)  {
/* ori   pointer to the beginning of the original seq
   anti  pointer to the beginning of the converted anti parallel sequence
   len   the length of the sequence, both original and converted
*/
   int chop =len-1;
   int m;
   for (m=0;m<len;m++) {
      switch(ori[m]) {
         case 'a': anti[chop-m] = 't'; break;
         case 'c': anti[chop-m] = 'g'; break;
         case 'g': anti[chop-m] = 'c'; break;
         case 't': anti[chop-m] = 'a'; break;
         case 'r': anti[chop-m] = 'y'; break;
         case 'y': anti[chop-m] = 'r'; break;
         case 'w': anti[chop-m] = 'w'; break;
         case 's': anti[chop-m] = 's'; break;
         case 'm': anti[chop-m] = 'k'; break;
         case 'k': anti[chop-m] = 'm'; break;
         case 'b': anti[chop-m] = 'v'; break;
         case 'd': anti[chop-m] = 'h'; break;
         case 'h': anti[chop-m] = 'd'; break;
         case 'v': anti[chop-m] = 'b'; break;
         case 'n': anti[chop-m] = 'n'; break;
         default:  /* bad character detection */
            fprintf(stderr,"Acck! In Anti_Par(), I don't like char# %d= %c! \n",m, ori[m]); break;
      }  /* end of switch/case statement */
   }
   anti[len] = '\0';
}


/***********************  Function Rev_Compl  *****************************************
*   Rev_Compl takes 2 char pointers, the 1st to the original seq, the 2nd to the      *
*   seq that it generates that is the reverse complement, and the length of the seq   *
*   to consider.                                                                      *
**************************************************************************************/

void Rev_Compl (char *orig, char *rev, int len)  {
/* variables same as in Anti_Par, above */
   Anti_Par (orig,rev,len);
   Reverse (rev);
}


/********************  Function reverse  ********************************
* straight from K+R (p62) - reverses a string s in place                *
************************************************************************/

void Reverse (char *s)  {
/* s  pointer to the beginning of the array that holds the seq to be reversed */
   int i,j;
   char c;
   for (i=0,j=strlen(s)-1; i<j; i++,j--) {
      c = s[i];     s[i] = s[j];      s[j] = c;
   }
}

/* Function Triplet_Reverse reverses a string triplet by triplet ie:
   ArgTrpPheAsnCys ==> CysAsnPheTrpArg  so as to make the 6 frame translations 
   readable in the oppo orientation */
void Triplet_Reverse (char *str) {
   int i, j, mid, length, itmp;
   char tmp[3];
   length =  strlen(str);
   mid = (int)(length / 2);
   for (i=0;i<=mid; i+=3) {
      for (j=0;j<3;j++) tmp[j] = str[i+j];
      for (j=0;j<3;j++) {
         itmp = length - i - 3 + j;
         str[i+j] = str[itmp];
         str[itmp] = tmp[j];
      }
   }
}


/*************************  Function hash  *******************************************************
*   function hash takes a pointer to the n-mer string and generates the                          *
*   integer equivalent degeneracies that n-mer can expand to (max of 256 in                      *
*   this instance (with a hexamer, and returns a pointer to that array of numbers (sum, below),  *
*   along with the integer number of degeneracies generated                                      *
*************************************************************************************************/
int hash(char *nmer, int sum[256], int num) { 
/* nmer  pointer to begin of array that holds the nmer to be 'hashed'
   sum   array (assigned in main() to be [256]) that holds the all the possible variants of the 
         hashed sequence
   num   length of the nmer to be hashed; yes I know it's redundant...
*/
   int key[6] = { 1, 4, 16, 64, 256, 1024};
         int el, h, N_degen, t_degen, degen, i;
   degen = N_degen = 1;
   memset(sum,0,sizeof(int)*256);  /* set all of 'sum' to 0 - should work but any faster?*/

   /* Big 'for' loop that calculates the hexamer, gets executed at every RE site, */
   for (el = 0;  el < num;  el++){        /* and at every overlapping n-mer */
      switch (nmer[el])  { /* pointer passed to function already offset to starting position */
      /* a=0, c=1, g=2, t=3, degenerates are handled below */
      case 'a':   break;   /* not really needed - (a) = 0 so no change in sum */
      case 'c': for (i=0; i<degen; i++) sum[i] = sum[i] + key[el];  break;
      case 'g': for (i=0; i<degen; i++) sum[i] = sum[i] + 2*key[el];  break;
      case 't': for (i=0; i<degen; i++) sum[i] = sum[i] + 3*key[el];  break;

      /*  !!!! Now the degeneracies !!!!  */
      /* Double degeneracies first */

      case 'y':   /* c or t  */  
         N_degen = degen*2; t_degen = N_degen-1;
         fill_out_sum (degen, N_degen, sum);
         for (i=0; i<(degen); i++)  {
            sum[i] = sum[i] + key[el];   /* counting up sum, incr for 'c'*/
            sum[t_degen-i] = sum[t_degen-i] + 3*key[el]; /* counting down sum,*/
         }  break;                                 /*    incr for 't' */
      case 'r':   /* g or a */
         N_degen = degen*2; 
         fill_out_sum(degen, N_degen, sum);
         for (i=0; i<(degen); i++)  {
         /*  'a' will give 0 - no change */
            sum[i] = sum[i] + 2*key[el];    /* counting up sum, incr for 'g' */
         }  break;
      case 'm':   /* a or c */
         N_degen = degen*2; 
         fill_out_sum(degen, N_degen, sum);
         for (i=0; i<(degen); i++)  {
         /*  'a' will give 0 - no change */
            sum[i] = sum[i] + key[el];    /* counting up sum, incr for 'c' */
         }  break;
      case 'k':   /* g or t */
         N_degen = degen*2;   t_degen = N_degen-1;
         fill_out_sum(degen, N_degen, sum);
         for (i=0; i<(degen); i++)  {
            sum[i] = sum[i] + 2*key[el];                 /* counting up sum, incr for 'g' */
            sum[t_degen-i] = sum[t_degen-i] + 3*key[el];  /* counting down sum, incr for 't' */
         }  break;
      case 's':   /* c or g */
         N_degen = degen*2;    t_degen = N_degen-1;
         fill_out_sum(degen, N_degen, sum);
         for (i=0; i<(degen); i++)  {
            sum[i] = sum[i] + key[el];                /* counting up sum, incr for 'c' */
            sum[t_degen-i] = sum[t_degen-i] + 2*key[el];  /* counting down sum, incr for 'g' */
         }  break;
      case 'w':   /* a or t */
         N_degen = degen*2;   
         fill_out_sum(degen, N_degen, sum);
         for (i=0; i<(degen); i++)  {
         /*  'a' will give 0 - no change */
            sum[i] = sum[i] + 3*key[el];    /* counting up sum, increment for 'c' */
         }  break;

      /* Triple degeneracies  */
      case 'b':   /* not a - so c, g, or t */
         h = 2*degen;   
         N_degen = degen*3;  
         fill_out_sum(degen, N_degen, sum);
         /* Increment all the array values in sum, based on the degeneracies */
         for (i=0; i<degen; i++)  {
         /*  'a' will give 0 - no change */
            sum[i] = sum[i] + key[el];    /* counting up sum, increment for 'c' */
            sum[i+degen] = sum[i+degen] + 2*key[el];    /* counting up sum, increm for 'g' */
            sum[i+h] = sum[i+h] + 3*key[el];    /* counting up sum, incr for 't' */
         } break;
      case 'd':   /* not c - so a, g, or t */
         h = 2*degen;    
         N_degen = degen*3;  
         fill_out_sum(degen, N_degen, sum);
         /* Increment all the array values in sum, based on the degeneracies */
         for (i=0; i<degen; i++)  {
         /*  'a' will give 0 - no change */
            sum[i+degen] = sum[i+degen] + 2*key[el];    /* counting up sum, incr for 'g' */
            sum[i+h] = sum[i+h] + 3*key[el];    /* counting up sum, incr for 't' */
         } break;
      case 'h':   /* not g - so a, c, or t */
         h = 2*degen;   
         N_degen = degen*3;  
         fill_out_sum(degen, N_degen, sum);
         /* Increment all the array values in sum, based on the degeneracies */
         for (i=0; i<degen; i++)  {
         /*  'a' will give 0 - no change */
            sum[i] = sum[i] + key[el];    /* counting up sum, increment for 'c' */
            sum[i+h] = sum[i+h] + 3*key[el];  /* counting up sum, incr for 't' */
         } break;
      case 'v':   /* not t - so a, c, or g */
         h = 2*degen;   
         N_degen = degen*3;  
         fill_out_sum(degen, N_degen, sum);
         /* Increment all the array values in sum, based on the degeneracies */
         for (i=0; i<degen; i++)  {
         /*  'a' will give 0 - no change */
            sum[i] = sum[i] + key[el];    /* counting up sum, increment for 'c' */
            sum[i+degen] = sum[i+degen] + 2*key[el]; /* counting up sum, incr for 'g' */
         } break;

      /* And the big old quadruple degeneracy  */
      case 'n':   /* a,c,g, or t */
         h = 2*degen;   
         N_degen = degen*4;      /* t_degen = N_degen-1; */
         fill_out_sum(degen, N_degen, sum);
         /* Increment all the array values in sum, based on the degeneracies */
         for (i=0; i<degen; i++)  {
         /*  'a' will give 0 - no change */
            sum[i] = sum[i] + key[el];    /* counting up sum, increment for 'c' */
            sum[i+degen] = sum[i+degen] + 2*key[el];    /* counting up sum, increment for 'g' */
            sum[i+h] = sum[i+h] + 3*key[el];    /* counting up sum, increment for 't' */
         } break;
      default:  /* bad character detection */
      fprintf (stderr, "Acck! in hash(), I don't like %c (at el = %d of %d)! \n", nmer[el], el, num); 
      break;
      }  /* end of switch/case statement */
      degen=N_degen;
   }  /* end of big 'for' loop */
   return degen;
}  


/***************************  Function Palindrome  ********************************
*   Function definition of palindrome - returns 1 if the sequence is a pal,       *
*   0 if it's not - fails on 1st nonpal character, so ought to fail quickly if    *
*   it is going to.                                                               *
**********************************************************************************/

int palindrome (char *site, int length) {
/* site     the site to be 'palindromed'; name should really be more generic
   length   the length of the sequence to be palindromed; yes, redundant, but convenient
*/
   int pal = 1, i = 0, halflength;
   if (length%2 == 0) halflength = length/2;
   else halflength=(length/2)+1;
   length--; /* to make the '*(site+(length-i)' expresssion work */
   while ((pal==1) && i<halflength) {
      switch (*(site+i)) {
         case 'a': if (*(site+(length-i)) != 't') pal=0; break;
         case 'c': if (*(site+(length-i)) != 'g') pal=0; break;
         case 'g': if (*(site+(length-i)) != 'c') pal=0; break;
         case 't': if (*(site+(length-i)) != 'a') pal=0; break;
         case 'y': if (*(site+(length-i)) != 'r') pal=0; break;
         case 'r': if (*(site+(length-i)) != 'y') pal=0; break;
         case 'm': if (*(site+(length-i)) != 'k') pal=0; break;
         case 'k': if (*(site+(length-i)) != 'm') pal=0; break;
         case 'w': if (*(site+(length-i)) != 'w') pal=0; break;
         case 's': if (*(site+(length-i)) != 's') pal=0; break;
         case 'b': if (*(site+(length-i)) != 'v') pal=0; break; 
         case 'd': if (*(site+(length-i)) != 'h') pal=0; break;
         case 'h': if (*(site+(length-i)) != 'd') pal=0; break;
         case 'v': if (*(site+(length-i)) != 'b') pal=0; break;
         case 'n': if (*(site+(length-i)) != 'n') pal=0; break;
         default: fprintf(stderr,"palindrome doesn't like %c! \n", *(site+i)); break;
      }  /* end of switch/case statement */
      i++;
   }
   return pal;
}


/***************************  Function fill_out_sum  *************************************
*   Function definition for fill_out_sum - duplicates the degeneracy the correct # of    *
*   times in the array 'sum[]'.                                                          *
*****************************************************************************************/
void fill_out_sum (int O_dgen, int N_dgen, int s[256])  {  
/* O_dgen   old degeneracy that needs to be updated to the new degeneracy defined in...
   N_dgen   new degeneracy that's calculated here
   s        local version of sum that holds all the degeneracy values calculated here  */
   int i = 0, j = 0;
   for (i=O_dgen; i<N_dgen; i=i+O_dgen) {
      do  {
         s[i+j] = s[j]; j++; 
      } while (j<O_dgen);
      j = 0;
   }
}

/* DownCase() downcases all the letters in the submitted string  */
char *DownCase(char *string){
   int i, len;
   char *downcased;
   len = strlen(string);
   downcased = (char *) calloc(len, sizeof(char)); /* 1st grab some space */
   if (downcased == NULL) { 
      fprintf(stderr, "Boom!! in Downcase(), calloc failed at getting downcased mem!\n");
      exit (1);
   }
   for (i=0; i<len; i++)  downcased[i] = tolower(string[i]);
   downcased[i] = '\0'; /* to terminate it properly */
   return downcased;
}


/* realhash() is a real hashing function, straight from Sedgewick (p233) that returns
        a good hash value within the scope of the allocated space, because of the mod 
        fn. tablesize MUST be prime for reliable results */ 
unsigned realhash(char *string2hash, int tablesize) {
   int hash;
   for (hash=0; *string2hash != '\0'; string2hash++){
       hash = (64 * hash + *string2hash) % tablesize;
   }
   return hash;
}


/* Usage() just spits out a few lines about how to use the program - shouldn't be more than 
        the smallest terminal screen that program is expected to see - say, 80x25. Well, in the
   old days it did this..     */
void Usage(void) {
fprintf (stderr, "Usage:   tacg -flag option -flag option ... <infile >outfile\n"
"tacg uses stdin/stdout/stderr; uses redirection or pipes for input and output;\n"
"needs input specifier (| or <); output to screen (default), >file, | nextcmd\n"
"Assumes ALL input is sequence altho non-IUPAC codes are filtered out.\n"
"One or more of: -F -g -G -l -L -O -P -s -S flags must be specified for output.\n"
"flag option    explanation (* = default; # = an integer)\n"
"-b   {#}       beginning of DNA subsequence; 1* for 1st base of sequence\n"
"-e   {#}       end of DNA subsequence; 0* for last base of sequence\n"
"-c             order output by # of hits per Enz, else by order in REBASE file\n"
"-C   {0*-7}    Codon Usage table to use for translation:\n"
"        0 - Universal;           1 - Mito_Vertebrates;  2 - Mito_Drosophila;\n"
"        3 - Mito_S_Cervisiae;    4 - Mito_S_Pombe;      5 - Mito_N_crassa;\n"
"        6 - Mito_Higher_Plants;  7 - Ciliates\n"
"-D {0|1*-4}    controls input and analysis of degenerate sequence where:\n"
"         0  FORCES excl'n IUPAC degen's in sequence; only 'acgtu' accepted\n"
"         1* cut as NONdegenerate unless IUPAC char's found; then cut as '-D3'\n"
"         2  allow IUPAC char's; ignore in KEY hex, but match outside of KEY\n"
"         3  allow IUPAC char's; find only EXACT matches\n"
"         4  allow IUPAC char's; find ALL POSSIBLE matches\n"
"-f   {0|1*}    form (or topology) of DNA - 0 (zero) for circular; 1 for linear\n"
"-F   {0*-3}    print/sort Fragments; 0*-omit; 1-unsorted; 2-sorted; 3-both\n"
"-g   {#>10}    prints a gel map w/ low end cutoff of # bp.\n"
"-G {#,X|Y|L}   streams numeric data to stdout for external analysis/plotting.\n"
"   # = bases/bin (the hits for this many bases should be pooled)\n"
"   X = bins on X axis; Y = bins on Y axis; L = Long output as 'bins(X) data(Y)\n"
"-h             asks for (this) brief help page\n"
"-H             asks for HTML tags to be generated on the fly for WWW output\n"
"-l             prints a GCG-style ladder map.\n"
"-L             print a Linear map - produces LOTS of output (~10x input)\n"
"-n {3*-8}    magnitude of recognition site; 3 = all, 5 = 5,6,7....\n"
"-m/M {#}       minimum (-m) and/or Maximum (-M) # cuts/RE; 0* for all\n"
"-o {0|1*|3|5}  overhang - 5=5', 3=3', 0 for blunt, 1(d) for all\n"
"-O {###,min}   ORF table for sel. frames (-O15,25 = fr 1,5; w/ min len of 25 aas\n"
"-p {name,pattern,Err} command line entry of (degenerate) patterns to search for\n"
"  eg:  -pFindMe,gyrttnnnnnnngct,1  looks for indicated pattern with 1 error\n"
"-P {Name1,[+-lg]DistLo[-DistHi],Name2}  Proximity matching for 2 named patterns\n"
"               Name1/2 patterns must be in a REBASE-format file in form:\n"
" 'Name1 1 IUPAC_pattern 0 Err !Comments '  where Err = max # errors allowed eg:\n"
" 'FindMe 1 gyrttnnnnnnngct 0 1 !The pattern that I'm trying to find \n"
"               can repeat to specify up to 10 relationships at once\n"
"               + (-) Name1 is downstream (upstream) of Name2; default either\n"
"               l (g) Name1 is < (>) or = to 'DistLo' from Name2\n"
" 'DistLo-DistHi'  indicates an explicit distance range (obviating l,g)\n"
"-q             (quiet) DISallows sending diagnostic info back to author\n"
"-r {name,name} selects SPECIFIC REs instead of by characeristic (max 15 names)\n "
"-R {alt REBASE file} specifies alternative REBASE file in GCG format\n"
"-s             summary - print Table of Zero Cutters, # hits of each Enzyme\n"
"-S             Sites - prints the the actual cut Sites in tabular form\n"
"-t/T {0|1*|3|6} Translation frames with 1 (-t) or 3 (-T) letter codes.\n"
"-v             asks for version of the program, then dies\n"
"-V             Verbose mode - spits lots of ugly diagnostics to std err\n"
"-w   {#}       output width in bp's (60 < # < 210), truncated to a # mod 15\n"
"examples: tacg -f0 -n6 -t3 -dsl -F3  <degen.input.file >output.file (to file)\n"
"          tacg -f 0 -l  -n 5 -t 3 -F 2 <input.seq.file  (to stdout/screen)\n"
"          readseq -f=8 input.seq -p | tacg -m 3 -T 1 -s  |grep HindIII >out\n"
"          tail +49 bigseqfile.genbank | tacg -n 6 -F 2 -l -L >outfile\n"
"          tacg -r HindIII,EcoRV,bamhi -O 134,30 -w 90 -LlS <input.seq.file\n"
"for more help, try 'man tacg'. Type 'Ctrl+C' if the program seems locked.\n"
"latest docs at: http://hornet.bio.uci.edu/~hjm/projects/tacg/tacg2.main.html\n\n");
}  

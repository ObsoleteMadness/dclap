/* ReadREs does just that - given a filename, it tries to open it and if successful, reads all the 
   uncommented REs into the global RE[] struct, and then returns the # of entries in RE (NumREs).  
   Matching against the SELECTED REs specified on the command line takes place after this functions 
   returns.   */
/* In Version 2, it also does a whole lot more, mostly related to creating the RE entries nec for doing the ERROR 
   matching. This involves reading a file, either a named REBASE formatted file or a temp file created in SetFlags to 
   carry the patterns entered via the -p flag.  These entries are parsed as usual, but if there's an error term at 
   the end, all the possible error terms are generated on the fly and entered into separate RE entries.  Each of these
   is compared with all previous RE entries back to the prototype to see if it's identical (fast and sloppy vs
   slow and careful, but it will match the majority without allowing too many duplicates).  When it verifies that 
   a generated pattern is really novel, it appends it.  For each error allowed, it generates
   an 'n' scan, much like a linker scan across the sequence, replacing each base with an n.  Obviously for Err=2, 
   it will do this 2x etc.  This is where a lot of the duplication occurs.  It also catches palindromes and only 
   checks them once.  It also trims leading and lagging n's to decrease the size of the sequence and further 
   reduce the size of succeeding scans.  As with the regular handling, it also finds the most significant hexamer
   profile in the sequence and uses the ~midpoint of that hex as the indicator site.  This reduces the amount of 
   offset calc'ns and also indicates the most significant match more easily. 
   There is an inefficiency in the backchecking as it checks ALL the previously stored entries instead of just the
   ones which share the same hexamer hash.  This inefficiency does not show up until you ask for lots of degeneracy
   in large sequences, so I'm not going to make it more efficient just yet.
   */

/* RebaseFile can be either the default or an optional filename - decided in/immed after SetFlags() */
/* RE[] is now global, so no need to declare it */
/* returns a pointer to hashtable[4096] which is composed in this fn() via a series of strange manipulations */
/* NumREs is now 'returned' via a pointer reference in the calling arguments */
#include <stdio.h>
#include <ctype.h>
#include <string.h> 
#include <stdlib.h>
#include <math.h>
#include "tacg.h" /* contains all the defines, includes, function prototypes for both main() and functions */


void BadMem(char* message, int exitcode) {
   fprintf(stderr, "Error on memory call: %s\n", message);
   exit(exitcode);
}

/* BestHexWWPal() does much of the calculation to set the RE values related to which way the extended check 
	should look (WW), what the best hexamer is, what the center of the site is, etc.  */
void BestHexWWPal(char *RE_rawsite, int len, int Cur) {
   int i, j, dpl=0, ori=1, BestHexIndex=0;
   float f=0, MaxSoFar=0;
/* for sites > 6, calc the sliding window of magnitudes to pick the best one */
   MaxSoFar = 0;
   if (len > 6) {
      for (i=0; i<len-5; i++) {
      f = MagCalc(RE_rawsite+i, 6);
         if (f > MaxSoFar) {
            MaxSoFar = f;
            BestHexIndex = i;
         /*  fprintf(stderr, "MSF=%f BHI = %d\n", MaxSoFar, BestHexIndex); */
         }
      } /* so now the best hex is chosen - now copy it in */
      RE[Cur].WW[ori] = 0 - BestHexIndex;   
      /* this can be further optimized but for now it's fine  */
      
      /* RE[Cur].E_tcut[ori] =  3;  tcut IS MIDPOINT OF  *besthex*  */
      
      for (j=0; j<6; j++) RE[Cur].E_hex[ori][j] = RE_rawsite[j+BestHexIndex]; /* copy the best hex to RE_hex - */
   } else { /* the site is < 6 bases, so it has to be filled with n's */
      i=j=0;   /* this is from previous code - not great but it works */
      while (j<6) {  
         if (RE_rawsite[i] == '\000') { /* if the site is shorter than a hexamer */
            while (j<6) RE[Cur].E_hex[ori][j++] = 'n'; /* pad out the site with n's */
         } else RE[Cur].E_hex[ori][j++] = RE_rawsite[i++]; /* else copy one to the other */
      } 
      RE[Cur].WW[ori] = 0;
   }
   if (RE[Cur].E_pal == 0)  {  /* if the RE is not a pal, do the things common to the normal ops 
                                       and the ERRORs ops; do the rest below  */
      Anti_Par(RE[Cur].E_hex[ori], RE[Cur].E_hex[dpl], 6); /* antipar and pop in the hex  */
      /* topcut, WW require a little jig */
      RE[Cur].WW[dpl] = 0 - RE[Cur].E_len + 6 - RE[Cur].WW[ori]; /* WW is negative */
      RE[Cur].E_tcut[dpl] = RE[Cur].E_len - RE[Cur].E_tcut[ori];    /* = 3; tcut IS MIDPOINT OF  *besthex*  */  
   }  /* end partial nonpalindrome handling */ 
}


int ReadEnz(char *EnzFileName, FILE *tmpfp, int *NumREs, char SelEnz[MAX_SEL_ENZ][11], int *hashtable[4096]) {
    
   int i, j, k, l, m, n, p, b, z,/* some of these counters can prob be re-used */
      dpl=0, ori=1,  /* these are the indices for the doppel and the original sequences - the 0 and 1 are reversed from
                        what you might ordinarily expect (o for ori, 1 for doppel) so that a 'for' loop will count up 
                        correctly to the right # - there will always be a 0 (ori), sometimes a 1 (doppel) */
      EORE,				/* End of RE - marks and tracks the mem used by RE */
      Nprotos=0,			/* # of protos to return at end */
      len, Degen, OLap, rep=0, rsl, thrashtable[4096], itemp1=0, itemp2=0, dgn_sits[256], BOStanza, EOStanza,
         SelREs, NumSelREs=0, RENameHash[RE_NAME_TAB_SIZ], VERBOSE, SEi, Err=0, proto, here, E, same, PPi;
   /* thrashtable is a temp holder for hashtable data to get the numbers; afterwards all the info will be  
      used to transferred to hashtable[], the pointer to which will be returned to main() and used thereafter.  
      thrashtable[] storage will die with this function, so its mem will be returned to the pool.  */
   float fRE_mag=0;
   char ctemp1[30], RE_rawsite[32], ct, s[10];

   FILE *fpinRE; 
   memset(RENameHash,0,sizeof(int)*RE_NAME_TAB_SIZ);
   memset(dgn_sits,0,sizeof(int)*256);
   memset(thrashtable,0,sizeof(int)*4096); 
  
   SelREs = (int)abs(flags[16]); /* this way because both '-r' and '-P' (puts a -1 in flags[16]) use SelEnz[] */
   VERBOSE = (int)flags[25];
   *NumREs=1;  /* this has to start at 1 rather than 0, because negation is used later to mark the doppels */
   EORE = INIT_RES;
   
/* If the -r flag has been set, hash the names into the name space */
   if (SelREs == 1) { /* both '-r' and '-P' use SelEnz[] - should act as the correct input filter for both */
      while ((SelEnz[NumSelREs][0] != ' ') && (NumSelREs < MAX_SEL_ENZ)) {
         RENameHash[realhash(SelEnz[NumSelREs], RE_NAME_TAB_SIZ)]++; /* incr the index */
         NumSelREs++;
      } /* and reset the '-n' and '-o' flags to default, regardless of what they were set to in SetFlags() */ 
      flags[1] = 3;  flags[2] = 1; 
   }
   
/* open the REbase input file, specified either by flag or by setting above */
   if (flags[29] == 1) { /* either the temp file opened and fed in SetFlags() */
      fpinRE = tmpfp; /* point one to the other */
      rewind(fpinRE); /* and rewind it */
   } else if ((fpinRE=fopen(EnzFileName,"r")) == NULL) {  /* or the standard/optional one from SetFlags() */
      fprintf(stderr,"Cannot open the REbase file \"%s\" for reading!!\n", EnzFileName); /* DON'T HIDE behind -V */
      exit(1); /* print an error and die gracefully */
   }

/*  Scan thru comments in rebase file to separator ("..")   */
   ctemp1[0] = 'k';   /* make sure the strcmp below fails the first time */
   while ((feof(fpinRE) == 0) && (strncmp(ctemp1, "..",2)!=0))  { 
      fscanf (fpinRE, "%2s", ctemp1); ct = 'm'; 
      while (ct != '\n' && ct != '\r') ct = fgetc(fpinRE); /* and read to end of line - this needs to be able to deal
      								with end of line conditions for Mac, Win, and unix - what have I missed? 
      								I think this is where the the lock-up happed with bad REBASE files */
   }

/* we're at "..", so go into file and start slurping directly data into struct
   except for RE_rawsite which has to be filtered a couple ways before being acceptable */

   while (((fscanf(fpinRE,"%s %d %s %d %s",ctemp1,&itemp1,RE_rawsite,&itemp2, s)) != EOF) && (*NumREs<MAX_NUM_RES)) { 
      /* remember that scanf vars have to be dereferenced (&var) unless pointers or arrays */
      ct = 'm'; while (ct != '\n' && ct != '\r') ct = fgetc(fpinRE); /* and read to end of line */      
      if ((ctemp1[0] != ';') && (strlen(RE_rawsite)<BASE_OVERLAP)) {  /* if the enz hasn't been commented out */
                                                                     /* and the recognition seq isn't overly long...*/
         if (s[0] != '!'){ /* and there's a number instead of the usual '!' */
            Err = atoi(s); /* hopefully this takes care of there sometimes being a #, sometimes a string in the REBASE */
            if (Err < 0 || Err > MAX_ERR) {
               fprintf(stderr, "Bad value for Error in REBASE format\n"); exit(1);
            }
         }
         /* This filters the entire recognition site from rebase.data to the REstruct.  Difference 
            from below is that it does it for the whole sequence, not just the 1st 6 bases for the hashtable */
         /* grab the raw site for labelling purposes */
         /* if no '-r' or ('-r' && current name hashes to a spot that one of the SelREs hashed to) */
         SEi = -1;    /* SE index */
         /* next line matches the name just read in (ctemp1) with the names entered in the SelEnz array.  Returns 
         	the index of the SelEnz match if one is found.  For -P, this match has to be further matched 
         	to the PP struct entry and FURTHER matched as to RE index (calc'ed here) so that we can fill 
         	out the PP[].REi[] value for Proximity() */
         if (SelREs == 1) SEi = MatchSelREs(ctemp1, SelEnz, NumSelREs);        

			/* Now match the names to those used in -P options so Proximity() knows what REs it's supposed to match */
			if (SEi != -1 && flags[30] >0) {  /* if there's a match and we need to match them for -P */
				for (i=0; i<flags[30]; i++) {  /*  check all the entries in PP[] for matches */
					for (j=0; j<2; j++) {  /* need to check both names of each PP[] entry */
						if (strcmp(SelEnz[SEi], PP[i].N[j]) == 0) {  /* if they match entries */
							PP[i].REi[j] = *NumREs;
						}
					}
				}
			}
         
         if (SelREs != 1 || SEi != -1) { 
            rsl = strlen(RE_rawsite)+1; /* rsl = Raw Site Length - used because of a perceived bug in GNU strcpy() */
            RE[*NumREs].E_raw_sit = (char *) calloc(rsl, sizeof(char)); /* 1st grab some space */
            if (RE[*NumREs].E_raw_sit == NULL) BadMem("calloc - RE[*NumREs].E_raw_sit", 1);
            
            strcpy(RE[*NumREs].E_raw_sit, RE_rawsite);  /* then copy it to RE_rawsite */
            /* Stanza to calc overhangs for matching to filter-by-overhang */         
            OLap = 1;     /* reset the default to take all the REs, regardless of overhang */
            /* calc overlap value for exclusion clause below */
            if (flags[2] != 1) {    /* if we want to restrict selection by overhang */
               if (itemp2 > 0) OLap = 5;           /* have to calc it */
               else if (itemp2 < 0) OLap = 3;
               else OLap = 0;
            }
            i=len=0;
            while (RE_rawsite[i] != '\000') {  /* while not at end of string  */
               if (RE_rawsite[i] != '_' && RE_rawsite[i] != '\'') { /*As long as it's a valid char */
                  RE_rawsite[len++] = tolower(RE_rawsite[i++]); /* The struct value gets the whole site */
               } else i++;  /* incr i only, skipping the _ and ' chars  */
            } 
            /* Here's where the 'nnn' detection/handling goes to trim trailing n's */
            while(RE_rawsite[--len]=='n');  /* back up until hit a non 'n' */
            RE_rawsite[++len] = '\0';     /* then restore the end of string mark */
        /* Now calculate E_mag exactly to see if it should be included in the digestion */
            fRE_mag = MagCalc(RE_rawsite, len); /* calculate the 'magnitude' of the pattern */        
            if (fRE_mag<2) fprintf(stderr, "Pattern named %s is too degenerate: Magnitude is only %4f.\n",ctemp1, fRE_mag);

            if (fRE_mag < flags[1] && flags[25] == 1) { /* only if you really want the verbiage... */
            	fprintf(stderr, "Pattern %s is too degenerate: Magnitude is only %4f.\n",ctemp1, fRE_mag);
            }
            
       /* don't bother loading any REs that don't match these criteria */
            if ((OLap == (int)flags[2]) && (fRE_mag >= (float)flags[1])) { 
               RE[*NumREs].E_mag = (int) fRE_mag; /* this truncates fRE_mag, but since it's upwardly inclusive ... */
               RE[*NumREs].E_wsit[ori] = (char *) calloc(len+1, sizeof(char));
               if (RE[*NumREs].E_wsit[ori] == NULL) BadMem("calloc - RE[*NumREs].E_wsit[ori]", 1);
               strncpy(RE[*NumREs].E_wsit[ori], RE_rawsite, len); /* E_wsit = the recog site, stripped of _ and ' and extra n's */
                  /* need a \0 to terminate ? - shouldn't - it's been calloc'ed to 0's*/
               RE[*NumREs].E_len = len;  /* set the real recog length since we calculated it */
               RE[*NumREs].E_pal = palindrome (RE[*NumREs].E_wsit[ori], len); /* and determine if the whole site is a pal */
               
         /* for Proximity() - Do all the matching for relating RE names in SelEnz and PP here, 
            as long as we have all the necessary vars to do it. */   
               if (flags[30] > 0) { /* if we need Proximity matching */
                  PPi = (int)SEi/2; /* the index is half of SEi, as there are 2 names per PP entry */
                  if (((SEi%2)-0.5) < 0.1) PP[PPi].REi[0] = *NumREs; /* which one of the 2 depends on the mod */
                  else PP[PPi].REi[1] = *NumREs;
               }
                              
         /* Filter the raw site from rebase.data to the hexamer val in struct
               that's submitted for the numeric conversion */
                /* And assign the rest of the temps to the struct vars */
               RE[*NumREs].E_nam_l = strlen(ctemp1); /* get the length of the RE name and pop it in */
               strcpy (RE[*NumREs].E_nam, ctemp1);    /* and pop the RE name in too */
               RE[*NumREs].E_tcut[ori] = itemp1; /* this is a temp val - corrected in BestHexWWPal() */
               RE[*NumREs].E_olap = itemp2;
               RE[*NumREs].Err = Err;
               RE[*NumREs].proto = *NumREs; /* so that it can point back to itself in the Cutting code */
					Nprotos++; /* count the protos so we can return the number at end */
/*               fprintf(stderr, "RE[%d].proto = %d\n", *NumREs, RE[*NumREs].proto); */
               i = *NumREs;
         /* this fn() does a lot of the calc'n / assignments common to normal and ERRORs code */
               BestHexWWPal(RE_rawsite, len, i); 
         /* Now do the ugly handling of nonpalindromes - this handles non-pal's as another entry in 
            the SAME RE entry and only adds those entries that are different - big savings in space  */
               if(RE[*NumREs].E_pal == 0)  {  /* if the RE is not a pal, do the rest  */
                  /* reverse complement and pop in the pattern sequence */
                  RE[*NumREs].E_wsit[dpl] = (char *) calloc(RE[*NumREs].E_len+1, sizeof(char));
                  if (RE[*NumREs].E_wsit[dpl] == NULL) BadMem("calloc - RE[*NumREs].E_wsit", 1);
                  Anti_Par(RE[*NumREs].E_wsit[ori], RE[*NumREs].E_wsit[dpl], RE[*NumREs].E_len);   
                }  /* end nonpalindrome handling */ 
                
         /* Here's where we figure out if we need to do the error matching and if so, create and check the sequences 
            that have to be checked.  Obviously, this is meant to be for a very few sequences at once; otherwise the 
            memory requirements explode */
         /* 1st - do we need to do this at all?  */   
					
               if (Err > 0 && Err < MAX_ERR) { /* if there is an ERROR term  */
                  /* now need to generate the list of names and validate that they're novel */
                  BOStanza = proto = *NumREs;   /* points to the prototype RE entry */
                  EOStanza = here = *NumREs+1;  /* pointer for the current RE entry */
                           
                  for (E=0; E<Err; E++) {    /* 1 iteration for each error level  */  
							if (flags[25] == 1) fprintf(stderr, "\t\tPrototype Expansion, Cycle %d\n", E);
							for (z=BOStanza; z<EOStanza; z++){  /* for Err=1, goes from 'proto' to 'here' */
		                  /* next 2 'for's are the core of the ERROR handling - build the ERROR templates  */
		                  /* 'n's at both ends effectively decr length by one - addressed below */
		                  len = RE[z].E_len ;  /* this may not be nec here, but if this code is fn()ized, it may be */
		                  for (j=0;j<len; j++) { /* for the length of the current (NOT nec the proto) pattern  */
		                     RE[here].E_wsit[ori] = (char *) calloc(RE[proto].E_len+1, sizeof(char));
		                     if (RE[here].E_wsit[ori] == NULL) BadMem("calloc - RE[here].E_wsit[ori]", 1); 
		                     
		                     for (i=0;i<len; i++) { /* for the length of the pattern */
		                        if (i==j) RE[here].E_wsit[ori][i] = 'n'; /* make an 'n' scan of the sequence */
		                        else RE[here].E_wsit[ori][i] = RE[z].E_wsit[ori][i];
		                     } 
		              /*       fprintf(stderr, "raw pat:%s\n", RE[here].E_wsit[ori]);  */
		                     /* now have a new, modified pattern - 1st trim n's from both ends and then ask is it novel? */
		                     RE[here].E_len = strlen(RE[here].E_wsit[ori]);  /*  the default len, unless otherwise mod'ed */
		                     if (RE[here].E_wsit[ori][0] == 'n'){  /*  if it starts with an 'n'  */
		                        p=0;  while (RE[here].E_wsit[ori][p] == 'n') p++;  /* if the beginning moves up, the len has to 
		                                                                              decrease, but not yet  */
		                        /* p should now point to the beginning of non-n sequence */
		                        memmove(&RE[here].E_wsit[ori][0], &RE[here].E_wsit[ori][p], len-p); /* move the seq up */
		                        RE[here].E_wsit[ori][len-p] = '\0'; /* terminate it again */
		                        RE[here].E_len = len-p; 
		                     }                    
		                     if (RE[here].E_wsit[ori][len-1] == 'n'){  /* and if it ends in an 'n' */
		                        b = len-1;
		                        while (RE[here].E_wsit[ori][b] == 'n')  b--; /* trim the back end of n's */
		                        b++;  /*  and incr to point to end */
		                        RE[here].E_wsit[ori][b] = '\0'; /* mark the p-adjusted end with a \0  */
		                        RE[here].E_len = b; 
		                     }  /* so now it should be trimmed fore and aft of n's */
		                     /*  1st decide if it's a pal, then do both at once, rather than do the ori then the doppel */               
		                     if (palindrome(RE[here].E_wsit[ori], RE[here].E_len) == 1) { /* if it's a pal.. */
		                        RE[here].E_pal = 1; /* just mark it - it will match the previous ones either way */
		                     } else { /* but if it's not a pal */
		                        RE[here].E_pal = 0;  /* also mark it as such and flip it to the AP in the dpl place */
		                        RE[here].E_wsit[dpl] = (char *) calloc(RE[here].E_len+1, sizeof(char));
		                        if (RE[here].E_wsit[dpl] == NULL) BadMem("calloc - RE[here].E_wsit[dpl]", 1); 
		                        Anti_Par(RE[here].E_wsit[ori], RE[here].E_wsit[dpl], RE[here].E_len); 
		                     }
		                     same = 0;
		                     /* and now check from where we STARTED on this stanza to where we ARE unless the seq is identical to 
		                        a previous one along the way - this way does both ori/dpl for both the current pattern as well 
		                        as the previous ones at the same time */
		                     for (m=proto;m<here && same == 0; m++) { /* match vs the ori AND doppel at each step with..*/
		                        if (RE[here].E_len == RE[m].E_len){
		                        	p=1;
		                        	if (RE[here].E_pal == 0) p=0; /* if !pal, have to do it 2x */
		                           for (n = 1; n>=p  && same==0; n--) { 
		                              b=1; rep=1;
		                              if (RE[m].E_pal == 0) { b=2; rep = 0; }/* if !pal, have to do it 2x */
		                              for (l=1; l>=rep  && same==0; l--) {  /*  ..the newly generated seq */
		                           /*     fprintf(stderr, "H=%d'%s' vs RE=%d'%s' s=%d \n", here, RE[here].E_wsit[n], m, RE[m].E_wsit[l], same);  */
		                           /*     fprintf(stderr, "%d\r ", here);   */
		                              	same = Degen_Cmp(RE[m].E_wsit[l], RE[here].E_wsit[n], RE[here].E_len, 2, 1);
		                              }
		                           }
		                     	}else same = 0; /* if they're ! the same size they can't be identical */
		                     }
		                     if (same == 0) { /* then it's scanned all the relevant RE bits and it really is novel.. */
		                                       /* so fill out the rest of the bits that need to be filled out */
		                        BestHexWWPal(RE[here].E_wsit[ori], RE[here].E_len, here); 
		                        RE[here].proto = proto;  /* set to credit the proto for cutting/labelling */
		                        here++;
		                     }  /* the above BestHexWWPal() should take care of the rest of the required values */
				               if (EORE - here + *NumREs < 12) {		
					            	if (flags[25] == 1) fprintf(stderr, "\nNeed mem for RE (prototype expansion)..");
					            	EORE += RE_INCR; 
					            	RE = realloc(RE, sizeof(*RE)*EORE);
					            	if (RE == NULL) BadMem("Failed to get more mem for RE.\n", 1);
					            	if (flags[25] == 1) fprintf(stderr, "..Got it! RE NOW contains %d elements\n", EORE);
					            }
		                  }  /* for (j=0;j<len; j++) ... */
		               }  /* for (z=BOStanza; z<EOStanza; z++) */
                  	BOStanza = EOStanza; /* and reset the Stanza markers to new values */
                  	EOStanza = here;
               	}  /* for (E=0; E<Err;E++) ... */
               	*NumREs = here; /* and sync the two - this handles all the incr of *NumREs in ERROR mode */
            	}  /* if (Err > 0 && Err < 4) ... */

            	if (Err == 0)(*NumREs)++;   /* if we're not handling ERRORs, incr it */
	            if (EORE - *NumREs < 12) {		
	            	if (flags[25] == 1) fprintf(stderr, "nNeed mem for RE..");
	            	EORE += RE_INCR; 
	            	RE = realloc(RE, sizeof(*RE)*EORE);
	            	if (RE == NULL) BadMem("Failed to get more mem for RE.\n", 1);
	            	if (flags[25] == 1) fprintf(stderr, "..Got it! RE NOW contains %d elements\n", EORE);
	            }
	            
            }  /* end of magnitude check */
         }                  
      } /* end of if statement that checks for ';' at beginning of RE name */
   } /* End of while loop that reads in  RE enzyme data into struct ... whew! */

   if (SelREs==1){ /* used in both -r and -P flags; adjust the checking above to extend past 1st check */
      for (i=0; i<MAX_SEL_ENZ; i++) {   /* check for RE names used in -r flag but not matched in REBASE used */      
         if ((SelEnz[i][10] != '*') && (SelEnz[i][0] != ' ')) { /* '*' indicates a match */
            fprintf(stderr, "Missing or Misspelled enzyme ('-r' flag): %s\n", SelEnz[i]); 
         }
      }
   }
   
/* Now need to cycle thru the struct, generating the hashtable and chk_sits arrays */

/* 1st, calc how many (NOT which - that's later) RE entries hash to a particular value in thrash/hashtable */
   for (m=1;m<*NumREs;m++) { /* start at 1, NOT 0, fool! */
      rep = 1;
      if (RE[m].E_pal == 0) rep = 0;
      for (k=1;k>=rep;k--) {  /* ugh - count down to catch the doppel */
         RE[m].E_dgen = hash(RE[m].E_hex[k], dgn_sits, 6); /* call to hash !!! */
         for (i=0; i<RE[m].E_dgen; i++) { /*  increment the thrashtable to reflect this degeneracy  */
            thrashtable[dgn_sits[i]]++;   /* incr the corresponding element of the array */
         }  
      }
   }  
       
/* Now calloc the space that chk_sits (now incorp into hashtable) needs using the data from above  */
   for (i=0;i<4096;i++){
    /* hashtable[4096][how many REs hash to this value + 1] */
      hashtable[i] = (int *) calloc((thrashtable[i]+1), sizeof(int)); 
      if (hashtable[i] == NULL) BadMem("ext mem for hashtable", 1);
      hashtable[i][0] = thrashtable[i];  /* and copy over the 1st element */
   } 

/* And finally rehash the enz list, filling out the hashtable array with the index of the RE struct 
   that has to be checked in the event that the sequence hashes to the chk_sits index - ugly to do 
   something twice like this, but it works pretty damn fast.  Using trashtable[1] as the pointer to keep
   track of where the next available space in hashtable is, rather than another element in hashtable itself
   as we already have that info in hashtable[0] */

	/* For next line, DON'T be tempted to use memset() - memset sets it on a per-byte basis, so for an
		int, each of the 4 or 2  bytes will be set to 1, yielding not 1 but some much larger number */
   for (j=0;j<4096;j++) thrashtable[j] = 1;  /* set it to 1 NOT 0; have to skip 0th el of hashtable */
	
   for (i=1;i<*NumREs;i++){ /* start at 1, NOT 0, fool! */
      rep = 1;
      if (RE[i].E_pal == 0) rep = 0;
      for (k=1;k>=rep;k--) {  /* ugh - count down to catch the doppel */
         Degen = hash(RE[i].E_hex[k], dgn_sits, 6);
         m = 1; if (k == 0) m = -1; /* set the multiplier for i below so that the doppel will be negated in 
                                       the hashtable, so we can tell later on what caused the hit */
         for (j=0;j<Degen;j++) hashtable[dgn_sits[j]] [thrashtable[dgn_sits[j]]++] = i*m; 
      }
   }
   /* the above results in hashtable[4096][....]  where the [0] element is the # of possible hits at 
   that hashvalue (the value in the original hashtable, when it was a 1D arrary) and the [1-#] 
   values are the indices of the RE entries that hash to this value (that in later exploits have to 
   be examined to discover whether they are true hits or not).  This new version of hashtable 
   eliminates chk_sits as well as shortening the allocation by one number ..wowee.  Not so much a 
   great space saving, but a simplification  */
   
   fclose(tmpfp);
   return Nprotos;
}

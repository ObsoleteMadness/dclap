#include <stdio.h>
#include <ctype.h> 
#include <string.h>
#include <stdlib.h>
#include "tacg.h" /* contains all the defines, includes, function prototypes for both main() and functions */


/* call Translate () on the dna sequence BEFORE call to ORF_Analysis, so to separate functions better and
   to keep from having to pass extra stuff thru functions just to pass on to deeper functions (don't have 
   to pass *sequence and mode to translate if call it before call to this */

void ORF_Analysis(char *prot, long protlen, short thisframe) {
   int   protCnt=0, /* counter that moves along the submitted protein til it hits end */
         aaCnt=0,    /* aa counter for the discovered orf */
         MinORF=flags[11], /* Min ORF Siz - ORF has to be at least this # of aas long or we ignore it */
         ORFNum=0,   /* # of the orf in sequence (thisframe only) */
         EOORF = 0,  /* start out being IN an orf unless otherwise told */
         Structsize = 100,
         ORF_End=100,      /* pointer to the end of ORF[][].orf */
         ORFstep=100; /* how much mem is calloc'ed at each incr for the orf length */
	thisframe--; /* to account for frame N referring to ORFs[N-1] */
/* BUT ALSO have to allocate mem for the whole ORF struct and keep testing if need more mem */
/* Get initial mem for the orf */
   ORFs[thisframe] =  calloc(Structsize, sizeof(*ORFs[0]) );
   if (ORFs[thisframe] == NULL) BadMem("ORF.c: calloc fails initial mem for ORFs!!\n",1);
   
   /* and for the initial length of the orf */
   ORFs[thisframe][ORFNum].orf = (char *) calloc(ORFstep, sizeof(char));
   if (ORFs[thisframe][ORFNum].orf == NULL)  BadMem("ORF.c: calloc fails @ ORFs[thisframe][ORFNum].orf!!\n",1); 
   
   /* if assume that we're starting in an ORF, have to initialize some counters, etc */
   ORFs[thisframe][ORFNum].frame = thisframe;
   ORFs[thisframe][ORFNum].B_offsetAA = 0; ORFs[thisframe][ORFNum].E_offsetAA = 0;
   ORFs[thisframe][ORFNum].B_offsetBP = 0; ORFs[thisframe][ORFNum].E_offsetBP = 0;

   while (protCnt < (int)protlen) {
      switch (prot[protCnt]) {
         case 'M':
            if (EOORF == 1) { 
               /* 1st - do we need more structs? */
               if (Structsize - ORFNum < 3){
               if (flags[25] == 1) fprintf(stderr, "Getting more ORF structs ...\n");
                  Structsize += 100;
                 ORFs[thisframe] =  realloc(ORFs[thisframe], sizeof(*ORFs[0])*Structsize); 
                  if (ORFs[thisframe] == NULL) BadMem("ORFs.c: calloc failed to get more mem for ORFs!!\n",1); 
               }
               /* now reset all the counters and do the bookkeeping for the next ORF */
               
               ORFNum++; aaCnt=0; ORFs[thisframe][ORFNum].frame = thisframe;
               ORF_End = ORFstep;  /* init the endpointer to the orf */
               if (thisframe < 3) {
                  ORFs[thisframe][ORFNum].B_offsetAA = (long)protCnt;   /* and the beginning offset in AAs*/
               	ORFs[thisframe][ORFNum].B_offsetBP = (long)(protCnt*3+thisframe+1);   /* and in BPs*/
               } else {
               	ORFs[thisframe][ORFNum].B_offsetAA = (long)(protlen-protCnt);   /* and the beginning offset in AAs*/
               	ORFs[thisframe][ORFNum].B_offsetBP = ((long)(protlen-protCnt)*3);   /* and in BPs*/
               
               }
               ORFs[thisframe][ORFNum].orf = (char *) calloc(ORFstep, sizeof(char));
               if (ORFs[thisframe][ORFNum].orf == NULL) BadMem("ORFs.c: calloc failed to get mem for NEXT ORFs!!\n",1);  
            }
            ORFs[thisframe][ORFNum].orf[aaCnt++] = prot[protCnt++];  /* copy and incre */
            EOORF = 0; /* and of course, indicate that we're not at the End Of Orf any more */
         break;

         case '*':      /* at end of the orf, just note it */
            if (EOORF != 1){
               EOORF = 1;
               if (aaCnt >= MinORF) {
                  ORFs[thisframe][ORFNum].orf[aaCnt] = '\0'; /* terminate the current orf string */
                  ORFs[thisframe][ORFNum].orflength = aaCnt; /* note the length */
                  if (thisframe < 3) {
                  	ORFs[thisframe][ORFNum].E_offsetAA = (long)protCnt;   /* and the ending offset */
                  	ORFs[thisframe][ORFNum].E_offsetBP = (long)(protCnt*3+thisframe);   /* and the ending offset */
                  } else {
                  	ORFs[thisframe][ORFNum].E_offsetAA = (long)(protlen-protCnt);   /* and the ending offset */
                  	ORFs[thisframe][ORFNum].E_offsetBP = (long)((protlen-protCnt)*3+thisframe);     /* -thisframe+3;   and the ending offset */
                  }
                  
                  ORF_Calcs(ORFNum, thisframe);
                  ORF_End = ORFstep; aaCnt = 0;
                  protCnt++; /* and increment over it */
               } else { /* it's too short - forget it and reset counters to the last ORF */
                  EOORF = 1; aaCnt = 0;
                  ORFNum--;  /* but DECR the ORF counter so we don't save too-short ORFs (overwrite the last one) */
               }
            } else {  /* then we've hit an in-frame stop NOT in an ORF soooo.. */
               protCnt ++;  /* just keep incr the pointer til we get to a 'M' */
            }
         break;

         default:  /* unless we're between orfs, just add the next aa to the current orf */
            if (EOORF != 1) {  /* if not 1, then we're in an ORF, so keep adding aas to the current ORF */
               ORFs[thisframe][ORFNum].orf[aaCnt++] = prot[protCnt];
            }  /* else we're not in an ORF, so ignore all aas until we hit another 'M' */
            protCnt++; /* but keep the protCnt incrementing regardless */
         break;
      }

      /* And then grab more mem if we get close to running out of it */

      if (ORF_End - aaCnt < 2) { /* check for end of alloced mem + get more if nec */
         ORF_End += ORFstep;
         ORFs[thisframe][ORFNum].orf = (char *)realloc(ORFs[thisframe][ORFNum].orf, sizeof(char)*ORF_End);
         if (ORFs[thisframe][ORFNum].orf == NULL) BadMem("ORFs.c:~105 calloc failed to get mem for NEXT ORFs!!\n",1);
      }
      
   }  /* while (protCnt < (int)protlen) { ... */

/* if there's an ORF in progress, see if it's greater than ORF and if so print it out as well.
   otherwise decr ORFNum, etc so that it will print out OK */
   if (EOORF != 1) {
      if (aaCnt >= MinORF) { 
         ORFs[thisframe][ORFNum].orf[aaCnt] = '\0'; /* terminate the current orf string */
         ORFs[thisframe][ORFNum].orflength = aaCnt; /* note the length */
         ORF_Calcs(ORFNum, thisframe);
      } else ORFNum--;
   }  /* if we're NOT in an ORF, no problems.. don't have to change anything */
   
   /* and now print out all the stats for thisframe */
   
   PrintORFs(ORFNum, thisframe, MinORF);
}

void PrintORFs(int ORFNum, int frame, int MinORF) {

   int i, f=frame; /* just for brevity */
   if (ORFNum < 0) ORFNum = 0; /* correcting a rare condition from calling fn() */
   
   fprintf(stdout, "\n == ORF Analysis for Frame %d:   %d ORF(s) > %d AAs\n", frame+1, ORFNum+1, MinORF);
   fprintf(stdout, " F#  ORF#   Begin(bp/AAs)     End(bp/AAs)   #AAs    MWt(KDa) \n");
   
   for (i=0; i<=ORFNum; i++) {
      fprintf(stdout, ">%2d  %4d %7ld /%6ld %7ld /%6ld   %4d %11.2f   \n%s\n", f+1, i+1, 
      (ORFs[f][i].B_offsetBP), ORFs[f][i].B_offsetAA, (ORFs[f][i].E_offsetBP), ORFs[f][i].E_offsetAA, 
      ORFs[f][i].orflength, ORFs[f][i].MolWt, ORFs[f][i].orf);
   }
}
   

void ORF_Calcs(int ORFNum, int f) { /* f = frame - just need to make it very short for lines below */
   int i,j;
   i = ORFNum;
   j = 0; ORFs[f][i].MolWt = 18;  /* this may have to be incr by 18 for the associated h20 */
   while (ORFs[f][i].orf[j] != '\0') {
      switch (ORFs[f][i].orf[j]) { /* following - template to add other calcs in afterwards */
         case 'A': ORFs[f][i].MolWt +=  71.08; break;
         case 'R': ORFs[f][i].MolWt += 156.2 ; break;
         case 'N': ORFs[f][i].MolWt += 114.11; break;
         case 'D': ORFs[f][i].MolWt += 115.09; break;
         case 'C': ORFs[f][i].MolWt += 103.14; break;
         case 'Q': ORFs[f][i].MolWt += 128.14; break;
         case 'E': ORFs[f][i].MolWt += 129.12; break;
         case 'G': ORFs[f][i].MolWt +=  57.06; break;
         case 'H': ORFs[f][i].MolWt += 137.15; break;
         case 'I': ORFs[f][i].MolWt += 113.17; break;
         case 'L': ORFs[f][i].MolWt += 113.17; break;
         case 'K': ORFs[f][i].MolWt += 128.18; break;
         case 'M': ORFs[f][i].MolWt += 131.21; break;
         case 'F': ORFs[f][i].MolWt += 147.18; break;
         case 'P': ORFs[f][i].MolWt +=  97.12; break;
         case 'S': ORFs[f][i].MolWt +=  87.08; break;
         case 'T': ORFs[f][i].MolWt += 101.11; break;
         case 'W': ORFs[f][i].MolWt += 186.21; break;
         case 'Y': ORFs[f][i].MolWt += 163.18; break;
         case 'V': ORFs[f][i].MolWt +=  99.14; break;
         
         case 'X': ORFs[f][i].MolWt += 118.89; 
            if (flags[25] ==1) fprintf(stderr, "UNKNOWN AA (X) in protein @ posit'n %d - CAREFUL!! Used "
           													"average wt (118.89 Da)\n", j);
         break; /* need this to deal with translation of degenerate sequences */
         
         /* won't have a '*' as it's been changed to a \0 above and \0 shouldn't be reached */
         default: 
            if (flags[25] ==1) fprintf(stderr, "Error (ORF_Calcs) - bad character (%c) in protein string..\n", 
            									ORFs[f][i].orf[j]);
         break; 
      }
      j++;
   }
}

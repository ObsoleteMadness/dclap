/* This is part of the Tar program */
#include <stdio.h>

void percent(curr, size)
long curr, size;
{
   static ratio = -1;
   register r1;

   r1 = (short)(size>21474836L ? curr/(size/100) : (100*curr)/size);
   if (r1 != ratio) {
      (void)fprintf(stderr, "%3d%%\b\b\b\b", ratio=r1);
      (void)fflush (stderr);
   }
}
